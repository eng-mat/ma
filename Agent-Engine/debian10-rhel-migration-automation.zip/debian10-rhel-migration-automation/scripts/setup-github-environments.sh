#!/usr/bin/env bash
# Creates the GitHub environments used by the three RHEL migration workflows.
#
# Usage: scripts/setup-github-environments.sh OWNER/REPO
#
# Every environment is restricted to protected branches, so approved runs can only
# execute reviewed code from the default branch. Required reviewers must then be
# added in Settings -> Environments (the API needs numeric team/user IDs):
#
#   rhel-prod-cutover        change approver / Cloud Operations lead
#   rhel-prod-data-signoff   build team lead (+ Cloud Operations)
#   rhel-prod-acceptance     application / service owner
#   rhel-prod-rollback       change approver (+ application owner)
#
# Tick "Prevent self-review" on each of those. The nonprod gate environments are
# created without reviewers (add some if your nonprod policy needs them).
set -euo pipefail

repo="${1:?usage: $0 OWNER/REPO}"

for env in nonprod prod; do
  for suffix in "" -cutover -data-signoff -acceptance -rollback; do
    name="rhel-${env}${suffix}"
    echo "Creating environment ${name}"
    gh api --method PUT "repos/${repo}/environments/${name}" \
      --input - <<'JSON' >/dev/null
{"deployment_branch_policy": {"protected_branches": true, "custom_branch_policies": false}}
JSON
  done
done

echo
echo "Done. Now add required reviewers to the rhel-prod-* gate environments (see header)."
echo "Set repository variables GCP_WIF_PROVIDER and GCP_MIGRATION_SERVICE_ACCOUNT"
echo "(or per-environment overrides, e.g. a separate prod service account)."

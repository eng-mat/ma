#!/usr/bin/env python3
"""Shared logic for the Debian 10 -> RHEL boot-disk migration workflows.

Used by three GitHub Actions entry points:
  * rhel-standard-migration.yml  (Workflow A - no data transfer required)
  * rhel-data-migration.yml      (Workflow B - build-team data migration + sign-off)
  * rhel-rollback.yml            (Workflow C - revert to the original Debian boot disk)

Design rules (see docs/ design document):
  * One VM per invocation.
  * Every command re-reads live GCP state before changing anything, so re-running a
    failed job resumes from where it stopped instead of repeating work.
  * Nothing is ever deleted. The original Debian boot disk, all snapshots and the
    RHEL boot disk are retained. Cleanup is a separate, manual, approved process.
  * Migration state lives in a GCS object per migration (durable, access-controlled),
    never in runner files or shell variables.
  * Metadata values are hashed, never logged, because they can contain secrets.

Standard library only. GCP access goes through the gcloud CLI, which is authenticated
by google-github-actions/auth using Workload Identity Federation (no JSON keys).
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

SCHEMA_VERSION = 1

# --------------------------------------------------------------------------- states
PRECHECK = "PRECHECK"
BACKUP_PREPARED = "BACKUP_PREPARED"
WAITING_FOR_DATA_MIGRATION = "WAITING_FOR_DATA_MIGRATION"
READY_FOR_CUTOVER = "READY_FOR_CUTOVER"
CUTOVER_IN_PROGRESS = "CUTOVER_IN_PROGRESS"
VALIDATION = "VALIDATION"
SUCCEEDED = "SUCCEEDED"
FAILED_ROLLBACK_REQUIRED = "FAILED_ROLLBACK_REQUIRED"
ON_HOLD = "ON_HOLD"
ROLLBACK_IN_PROGRESS = "ROLLBACK_IN_PROGRESS"
ROLLBACK_VALIDATION = "ROLLBACK_VALIDATION"
ROLLED_BACK = "ROLLED_BACK"
ROLLBACK_FAILED = "ROLLBACK_FAILED"

TRANSITIONS: dict[str | None, set[str]] = {
    None: {PRECHECK, ON_HOLD},
    PRECHECK: {BACKUP_PREPARED, ON_HOLD},
    BACKUP_PREPARED: {WAITING_FOR_DATA_MIGRATION, READY_FOR_CUTOVER, ON_HOLD},
    WAITING_FOR_DATA_MIGRATION: {READY_FOR_CUTOVER, ON_HOLD},
    READY_FOR_CUTOVER: {CUTOVER_IN_PROGRESS, ON_HOLD},
    CUTOVER_IN_PROGRESS: {VALIDATION, FAILED_ROLLBACK_REQUIRED, ROLLBACK_IN_PROGRESS},
    VALIDATION: {SUCCEEDED, FAILED_ROLLBACK_REQUIRED, ROLLBACK_IN_PROGRESS},
    SUCCEEDED: {ROLLBACK_IN_PROGRESS},
    FAILED_ROLLBACK_REQUIRED: {ROLLBACK_IN_PROGRESS},
    # ON_HOLD can be resumed only through the guarded commands (preflight / signoff /
    # cutover), each of which re-runs its own checks first.
    ON_HOLD: {PRECHECK, READY_FOR_CUTOVER},
    ROLLBACK_IN_PROGRESS: {ROLLBACK_VALIDATION, ROLLBACK_FAILED},
    ROLLBACK_VALIDATION: {ROLLED_BACK, ROLLBACK_FAILED},
    ROLLBACK_FAILED: {ROLLBACK_IN_PROGRESS},
    ROLLED_BACK: set(),
}

# A VM with a migration in one of these states cannot start another migration.
BLOCKING_STATES = {
    PRECHECK, BACKUP_PREPARED, WAITING_FOR_DATA_MIGRATION, READY_FOR_CUTOVER,
    CUTOVER_IN_PROGRESS, VALIDATION, SUCCEEDED, FAILED_ROLLBACK_REQUIRED,
    ROLLBACK_IN_PROGRESS, ROLLBACK_VALIDATION, ROLLBACK_FAILED,
}
# States from which the rollback workflow may act (the VM was, or may have been, cut over).
ROLLBACK_ELIGIBLE = {
    CUTOVER_IN_PROGRESS, VALIDATION, SUCCEEDED, FAILED_ROLLBACK_REQUIRED,
    ROLLBACK_IN_PROGRESS, ROLLBACK_FAILED,
}

PATH_CLASSIFICATION = {"standard": "STANDARD", "data": "DATA_MIGRATION_REQUIRED"}
INVENTORY_COLUMNS = [
    "project_id", "zone", "vm_name", "environment", "boot_disk", "classification",
    "assessment_date", "assessment_owner", "app_owner", "validation_owner",
    "data_migration_plan_ref",
]

COMPUTE_API = "https://compute.googleapis.com/compute/v1"
CRM_API = "https://cloudresourcemanager.googleapis.com/v1"

INSTANCE_PERMS = [
    "compute.instances.get", "compute.instances.stop", "compute.instances.start",
    "compute.instances.attachDisk", "compute.instances.detachDisk",
    "compute.instances.getSerialPortOutput",
]
SOURCE_DISK_PERMS = ["compute.disks.get", "compute.disks.use", "compute.disks.createSnapshot"]
PROJECT_PERMS = [
    "compute.disks.create", "compute.disks.get", "compute.disks.use", "compute.disks.setLabels",
    "compute.snapshots.create", "compute.snapshots.get", "compute.snapshots.setLabels",
]
IMAGE_PERMS = ["compute.images.get", "compute.images.useReadOnly"]

TARGET_PATTERNS = {
    "project_id": r"[a-z][a-z0-9-]{4,28}[a-z0-9]",
    "zone": r"[a-z]+-[a-z]+[0-9]+-[a-z]",
    "vm_name": r"[a-z]([-a-z0-9]{0,61}[a-z0-9])?",
    "migration_id": r"mig-[a-z0-9-]{1,40}",
}


class PreconditionFailed(Exception):
    """A guarded check failed; the workflow must stop and hold the VM."""

    def __init__(self, failures: list[str]):
        super().__init__("; ".join(failures))
        self.failures = failures


class GcloudError(RuntimeError):
    pass


class NotFound(GcloudError):
    pass


class Conflict(GcloudError):
    pass


# --------------------------------------------------------------------------- helpers
def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def iso(t: dt.datetime) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def basename(url: str | None) -> str | None:
    return url.rstrip("/").rsplit("/", 1)[-1] if url else None


def log(msg: str) -> None:
    print(msg, flush=True)


def warn(msg: str) -> None:
    print(f"::warning::{msg}", flush=True)


def error(msg: str) -> None:
    print(f"::error::{msg}", flush=True)


def set_output(key: str, value: str) -> None:
    path = os.environ.get("GITHUB_OUTPUT")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"{key}={value}\n")
    log(f"output {key}={value}")


def summary(markdown: str) -> None:
    path = os.environ.get("GITHUB_STEP_SUMMARY")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(markdown.rstrip() + "\n\n")
    else:
        log(markdown)


def rname(*parts: str) -> str:
    """Build a valid Compute Engine resource name (RFC 1035, max 63 chars)."""
    raw = "-".join(p for p in parts if p).lower()
    name = re.sub(r"-+", "-", re.sub(r"[^a-z0-9-]", "-", raw)).strip("-")
    if not name or not name[0].isalpha():
        name = "r-" + name
    if len(name) > 63:
        digest = hashlib.sha256(raw.encode()).hexdigest()[:8]
        name = name[:54].rstrip("-") + "-" + digest
    return name


def label_value(value: str) -> str:
    return re.sub(r"[^a-z0-9_-]", "-", value.lower())[:63]


def kms_key_name(disk: dict) -> str | None:
    key = (disk.get("diskEncryptionKey") or {}).get("kmsKeyName")
    return re.sub(r"/cryptoKeyVersions/\d+$", "", key) if key else None


def boot_entry(inst: dict) -> dict | None:
    return next((d for d in inst.get("disks", []) if d.get("boot")), None)


def boot_disk_name(inst: dict) -> str | None:
    entry = boot_entry(inst)
    return basename(entry.get("source")) if entry else None


def data_disk_entries(inst: dict) -> list[dict]:
    return [d for d in inst.get("disks", []) if not d.get("boot")]


def vm_baseline(inst: dict, metadata_ignore: list[str]) -> dict:
    """Normalised VM configuration that a boot-disk swap must not change.

    Metadata values are hashed so secrets in startup scripts etc. never reach the
    state store or the logs. External NAT IPs are excluded because ephemeral external
    IPs legitimately change on stop/start (preflight warns about this instead).
    """
    items = sorted(
        (i["key"], i.get("value", ""))
        for i in (inst.get("metadata") or {}).get("items", [])
        if i["key"] not in metadata_ignore
    )
    nics = []
    for nic in inst.get("networkInterfaces", []):
        nics.append({
            "network": basename(nic.get("network")),
            "subnetwork": basename(nic.get("subnetwork")),
            "networkIP": nic.get("networkIP"),
            "accessConfigs": sorted(a.get("type", "") for a in nic.get("accessConfigs", [])),
            "aliasIpRanges": sorted(a.get("ipCidrRange", "") for a in nic.get("aliasIpRanges", [])),
        })
    return {
        "id": str(inst.get("id")),
        "machineType": basename(inst.get("machineType")),
        "serviceAccounts": sorted(
            [sa.get("email"), sorted(sa.get("scopes", []))] for sa in inst.get("serviceAccounts", [])
        ),
        "tags": sorted((inst.get("tags") or {}).get("items", [])),
        "labels": dict(sorted((inst.get("labels") or {}).items())),
        "metadataKeys": [k for k, _ in items],
        "metadataSha256": hashlib.sha256(json.dumps(items).encode()).hexdigest(),
        "networkInterfaces": nics,
        "shieldedInstanceConfig": inst.get("shieldedInstanceConfig") or {},
        "guestAccelerators": sorted(
            f"{basename(a.get('acceleratorType'))}x{a.get('acceleratorCount')}"
            for a in inst.get("guestAccelerators", [])
        ),
        "dataDisks": sorted(
            [basename(d.get("source")), d.get("deviceName"), d.get("mode")] for d in data_disk_entries(inst)
        ),
    }


SOFT_BASELINE_FIELDS = {"labels"}  # differences are reported as warnings only


def diff_baseline(expected: dict, actual: dict) -> tuple[list[str], list[str]]:
    hard, soft = [], []
    for key in sorted(set(expected) | set(actual)):
        if expected.get(key) != actual.get(key):
            msg = f"VM configuration changed: {key} (expected {expected.get(key)!r}, found {actual.get(key)!r})"
            if key == "metadataSha256":
                msg = "VM configuration changed: metadata values differ from the recorded baseline"
            (soft if key in SOFT_BASELINE_FIELDS else hard).append(msg)
    return hard, soft


def run_context() -> dict:
    server = os.environ.get("GITHUB_SERVER_URL", "")
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    run_id = os.environ.get("GITHUB_RUN_ID", "")
    return {
        "actor": os.environ.get("GITHUB_ACTOR", os.environ.get("USERNAME", "local")),
        "triggering_actor": os.environ.get("GITHUB_TRIGGERING_ACTOR", ""),
        "workflow": os.environ.get("GITHUB_WORKFLOW", "local"),
        "job": os.environ.get("GITHUB_JOB", ""),
        "run_id": run_id,
        "run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT", ""),
        "run_url": f"{server}/{repo}/actions/runs/{run_id}" if run_id else "",
        "sha": os.environ.get("GITHUB_SHA", ""),
    }


# --------------------------------------------------------------------------- gcloud
class Gcloud:
    """Thin wrapper over the gcloud CLI. Tests substitute an in-memory fake."""

    NOT_FOUND = re.compile(r"was not found|notFound|HTTPError 404|code=404|\b404\b|NOT_FOUND", re.I)
    PRECONDITION = re.compile(r"\b412\b|PreconditionFailed|conditionNotMet", re.I)

    def __init__(self) -> None:
        self.bin = shutil.which("gcloud") or "gcloud"
        self._token: str | None = None

    def _run(self, args: list[str], quiet_log: bool = False) -> str:
        if not quiet_log:
            log("$ gcloud " + " ".join(args))
        proc = subprocess.run([self.bin, *args, "--quiet"], capture_output=True, text=True)
        if proc.returncode != 0:
            err = proc.stderr.strip()
            if self.PRECONDITION.search(err):
                raise Conflict(err)
            if self.NOT_FOUND.search(err):
                raise NotFound(err)
            raise GcloudError(f"gcloud {' '.join(args[:3])} failed: {err}")
        return proc.stdout

    def _json(self, args: list[str]) -> dict | None:
        try:
            return json.loads(self._run([*args, "--format=json"], quiet_log=True))
        except NotFound:
            return None

    # ---- reads
    def instance(self, project: str, zone: str, name: str) -> dict | None:
        return self._json(["compute", "instances", "describe", name, f"--project={project}", f"--zone={zone}"])

    def disk(self, project: str, zone: str, name: str) -> dict | None:
        return self._json(["compute", "disks", "describe", name, f"--project={project}", f"--zone={zone}"])

    def snapshot(self, project: str, name: str) -> dict | None:
        return self._json(["compute", "snapshots", "describe", name, f"--project={project}"])

    def image(self, project: str, name: str | None = None, family: str | None = None) -> dict | None:
        if family:
            return self._json(["compute", "images", "describe-from-family", family, f"--project={project}"])
        return self._json(["compute", "images", "describe", name, f"--project={project}"])

    def kms_key(self, key: str) -> dict | None:
        try:
            return self._json(["kms", "keys", "describe", key])
        except GcloudError:
            return None

    def serial_output(self, project: str, zone: str, name: str) -> str:
        try:
            return self._run(["compute", "instances", "get-serial-port-output", name,
                              f"--project={project}", f"--zone={zone}", "--port=1"], quiet_log=True)
        except GcloudError:
            return ""

    def os_inventory(self, project: str, zone: str, name: str) -> str:
        try:
            return self._run(["compute", "instances", "os-inventory", "describe", name,
                              f"--project={project}", f"--zone={zone}", "--format=json"], quiet_log=True)
        except GcloudError:
            return ""

    # ---- writes (each gcloud call waits for its operation to finish)
    def stop(self, project: str, zone: str, name: str) -> None:
        self._run(["compute", "instances", "stop", name, f"--project={project}", f"--zone={zone}"])

    def start(self, project: str, zone: str, name: str) -> None:
        self._run(["compute", "instances", "start", name, f"--project={project}", f"--zone={zone}"])

    def detach_disk(self, project: str, zone: str, name: str, disk: str) -> None:
        self._run(["compute", "instances", "detach-disk", name, f"--disk={disk}",
                   f"--project={project}", f"--zone={zone}"])

    def attach_boot_disk(self, project: str, zone: str, name: str, disk: str, device_name: str) -> None:
        self._run(["compute", "instances", "attach-disk", name, f"--disk={disk}", "--boot",
                   f"--device-name={device_name}", f"--project={project}", f"--zone={zone}"])

    def create_snapshot(self, project: str, name: str, source_disk: str, zone: str, labels: dict,
                        kms_key: str | None, storage_location: str | None, guest_flush: bool,
                        description: str) -> None:
        args = ["compute", "snapshots", "create", name, f"--project={project}",
                f"--source-disk={source_disk}", f"--source-disk-zone={zone}",
                "--labels=" + ",".join(f"{k}={v}" for k, v in labels.items()),
                f"--description={description}"]
        if kms_key:
            args.append(f"--kms-key={kms_key}")
        if storage_location:
            args.append(f"--storage-location={storage_location}")
        if guest_flush:
            args.append("--guest-flush")
        self._run(args)

    def create_disk(self, project: str, zone: str, name: str, image: dict, disk_type: str, size_gb: int,
                    labels: dict, kms_key: str | None, resource_policies: list[str],
                    provisioned_iops: str | None, provisioned_throughput: str | None, description: str) -> None:
        args = ["compute", "disks", "create", name, f"--project={project}", f"--zone={zone}",
                f"--image={image['name']}", f"--image-project={image['project']}",
                f"--type={disk_type}", f"--size={size_gb}GB",
                "--labels=" + ",".join(f"{k}={v}" for k, v in labels.items()),
                f"--description={description}"]
        if kms_key:
            args.append(f"--kms-key={kms_key}")
        if resource_policies:
            args.append("--resource-policies=" + ",".join(resource_policies))
        if provisioned_iops:
            args.append(f"--provisioned-iops={provisioned_iops}")
        if provisioned_throughput:
            args.append(f"--provisioned-throughput={provisioned_throughput}")
        self._run(args)

    # ---- IAM checks (REST; gcloud has no testIamPermissions command)
    def _token_value(self) -> str:
        if not self._token:
            self._token = self._run(["auth", "print-access-token"], quiet_log=True).strip()
        return self._token

    def missing_permissions(self, url: str, perms: list[str]) -> list[str] | None:
        """Return the permissions NOT granted on the resource, or None if the check itself failed."""
        req = urllib.request.Request(
            url, data=json.dumps({"permissions": perms}).encode(), method="POST",
            headers={"Authorization": f"Bearer {self._token_value()}", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                granted = set(json.load(resp).get("permissions", []))
        except (urllib.error.URLError, ValueError) as exc:
            warn(f"Permission check could not run for {url}: {exc}")
            return None
        return [p for p in perms if p not in granted]

    # ---- state store (GCS)
    def storage_read(self, url: str) -> tuple[dict | None, int]:
        meta = self._json(["storage", "objects", "describe", url])
        if not meta:
            return None, 0
        # Describe first, then read: if the object changes in between, the later
        # generation-matched write fails safely instead of overwriting unseen data.
        generation = int(meta.get("generation") or 0)
        text = self._run(["storage", "cat", url], quiet_log=True)
        return json.loads(text), generation

    def storage_write(self, url: str, doc: dict, if_generation: int) -> int:
        fd, path = tempfile.mkstemp(suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(doc, f, indent=2, sort_keys=True)
            self._run(["storage", "cp", path, url, f"--if-generation-match={if_generation}",
                       "--content-type=application/json"], quiet_log=True)
        finally:
            os.unlink(path)
        meta = self._json(["storage", "objects", "describe", url]) or {}
        return int(meta.get("generation") or 0)

    def storage_list(self, prefix: str) -> list[str]:
        try:
            out = self._run(["storage", "ls", prefix], quiet_log=True)
        except GcloudError as exc:
            if "matched no objects" in str(exc) or isinstance(exc, NotFound):
                return []
            raise
        return [line.strip() for line in out.splitlines() if line.strip().endswith(".json")]


def github_approvals(environment_name: str) -> list[dict] | None:
    """Deployment-review history for this run, filtered to one GitHub environment."""
    token = os.environ.get("GITHUB_TOKEN")
    repo = os.environ.get("GITHUB_REPOSITORY")
    run_id = os.environ.get("GITHUB_RUN_ID")
    if not (token and repo and run_id):
        return None
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    req = urllib.request.Request(
        f"{api}/repos/{repo}/actions/runs/{run_id}/approvals",
        headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
                 "X-GitHub-Api-Version": "2022-11-28"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            reviews = json.load(resp)
    except (urllib.error.URLError, ValueError) as exc:
        warn(f"Could not read deployment approvals from GitHub: {exc}")
        return None
    return [
        {"user": r.get("user", {}).get("login"), "state": r.get("state"),
         "comment": (r.get("comment") or "")[:500], "environment": environment_name}
        for r in reviews
        if any(e.get("name") == environment_name for e in r.get("environments", []))
    ]


# --------------------------------------------------------------------------- state store
class Record:
    """One migration's durable record, saved with generation preconditions."""

    def __init__(self, store: "StateStore", url: str, doc: dict | None, generation: int):
        self.store, self.url, self.doc, self.generation = store, url, doc, generation

    @property
    def state(self) -> str | None:
        return self.doc.get("state") if self.doc else None

    def _append(self, entry: dict) -> None:
        self.doc.setdefault("history", []).append({"at": iso(utcnow()), **run_context(), **entry})

    def save(self) -> None:
        self.doc["updated_at"] = iso(utcnow())
        self.generation = self.store.gc.storage_write(self.url, self.doc, self.generation)

    def transition(self, new_state: str, note: str = "", **fields) -> None:
        old = self.state
        if new_state not in TRANSITIONS.get(old, set()):
            raise PreconditionFailed([f"Illegal state transition {old} -> {new_state}"])
        self.doc.update(fields)
        self.doc["state"] = new_state
        if new_state == ON_HOLD:
            self.doc["held_from"] = old
        self._append({"event": "STATE_CHANGE", "from": old, "to": new_state, "note": note})
        self.save()
        log(f"State: {old} -> {new_state}{(' (' + note + ')') if note else ''}")

    def event(self, name: str, note: str = "", **details) -> None:
        self._append({"event": name, "note": note, **({"details": details} if details else {})})
        self.save()


class StateStore:
    def __init__(self, gc: Gcloud, bucket: str, prefix: str):
        self.gc, self.bucket, self.prefix = gc, bucket, prefix.strip("/")

    def vm_prefix(self, project: str, zone: str, vm: str) -> str:
        return f"gs://{self.bucket}/{self.prefix}/{project}/{zone}/{vm}/"

    def load(self, project: str, zone: str, vm: str, migration_id: str) -> Record:
        url = f"{self.vm_prefix(project, zone, vm)}{migration_id}.json"
        doc, generation = self.gc.storage_read(url)
        return Record(self, url, doc, generation)

    def all_for_vm(self, project: str, zone: str, vm: str) -> list[dict]:
        docs = []
        for url in self.gc.storage_list(self.vm_prefix(project, zone, vm)):
            doc, _ = self.gc.storage_read(url)
            if doc:
                docs.append(doc)
        return docs


# --------------------------------------------------------------------------- context
class Ctx:
    def __init__(self, args: argparse.Namespace, cfg: dict, gc: Gcloud,
                 approvals_fn=github_approvals, now_fn=utcnow, sleep_fn=time.sleep):
        self.args, self.cfg, self.gc = args, cfg, gc
        self.project, self.zone, self.vm = args.project_id, args.zone, args.vm_name
        self.environment, self.migration_id = args.environment, args.migration_id
        self.approvals_fn, self.now, self.sleep = approvals_fn, now_fn, sleep_fn
        self.store = StateStore(gc, cfg["state_bucket"], cfg.get("state_prefix", "rhel-migrations"))
        self.label_prefix = cfg.get("label_prefix", "rhel-migration")

    def labels(self, role: str) -> dict:
        return {
            f"{self.label_prefix}-id": label_value(self.migration_id),
            f"{self.label_prefix}-vm": label_value(self.vm),
            f"{self.label_prefix}-role": label_value(role),
        }

    def record(self) -> Record:
        return self.store.load(self.project, self.zone, self.vm, self.migration_id)

    def required_record(self) -> Record:
        rec = self.record()
        if not rec.doc:
            raise PreconditionFailed([f"No migration record {self.migration_id} for {self.project}/{self.zone}/{self.vm}"])
        for key, value in (("project_id", self.project), ("zone", self.zone), ("vm_name", self.vm),
                           ("environment", self.environment)):
            if rec.doc.get(key) != value:
                raise PreconditionFailed([f"Migration {self.migration_id} belongs to {key}={rec.doc.get(key)!r}, not {value!r}"])
        return rec

    def instance(self) -> dict | None:
        return self.gc.instance(self.project, self.zone, self.vm)

    def wait_for(self, what: str, fn, timeout: int, poll: int):
        deadline = time.monotonic() + timeout
        while True:
            result = fn()
            if result:
                return result
            if time.monotonic() >= deadline:
                return None
            log(f"Waiting for {what} ...")
            self.sleep(poll)


# --------------------------------------------------------------------------- shared checks
def load_inventory_row(ctx: Ctx) -> tuple[dict | None, list[str]]:
    path = ctx.cfg.get("inventory_path", "inventory/vm_inventory.csv")
    if not os.path.exists(path):
        return None, [f"Inventory file {path} not found"]
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing_cols = [c for c in INVENTORY_COLUMNS if c not in (reader.fieldnames or [])]
        if missing_cols:
            return None, [f"Inventory is missing columns: {', '.join(missing_cols)}"]
        rows = [
            {k: (v or "").strip() for k, v in r.items() if k}
            for r in reader
            if (r.get("project_id") or "").strip() == ctx.project
            and (r.get("zone") or "").strip() == ctx.zone
            and (r.get("vm_name") or "").strip() == ctx.vm
        ]
    if not rows:
        return None, ["VM is not in the approved inventory; it stays on hold until assessed"]
    if len(rows) > 1:
        return None, [f"Inventory has {len(rows)} conflicting rows for this VM"]
    return rows[0], []


def check_eligibility(ctx: Ctx, row: dict, path: str) -> list[str]:
    failures = []
    expected = PATH_CLASSIFICATION[path]
    if row["classification"] != expected:
        failures.append(f"Inventory classification is {row['classification'] or 'empty'}; this workflow requires {expected}")
    if row["environment"] != ctx.environment:
        failures.append(f"Inventory environment is {row['environment']!r}, run requested {ctx.environment!r}")
    try:
        assessed = dt.date.fromisoformat(row["assessment_date"])
        age = (ctx.now().date() - assessed).days
        max_age = int(ctx.cfg.get("assessment_max_age_days", 30))
        if age < 0:
            failures.append(f"Assessment date {assessed} is in the future")
        elif age > max_age:
            failures.append(f"Assessment from {assessed} is stale ({age} days > {max_age}); re-inspect the guest")
    except ValueError:
        failures.append(f"Assessment date {row['assessment_date']!r} is missing or not YYYY-MM-DD")
    for col in ("assessment_owner", "app_owner", "validation_owner"):
        if not row[col]:
            failures.append(f"Inventory field {col} is empty")
    if path == "data" and not row["data_migration_plan_ref"]:
        failures.append("Inventory field data_migration_plan_ref is empty; a workload-specific data plan is required")
    return failures


def resolve_image(ctx: Ctx) -> tuple[dict | None, list[str]]:
    spec = ctx.cfg.get("approved_image") or {}
    project = spec.get("project")
    if not project or "REPLACE" in project:
        return None, ["approved_image.project is not configured"]
    if spec.get("image"):
        img = ctx.gc.image(project, name=spec["image"])
    elif spec.get("family"):
        img = ctx.gc.image(project, family=spec["family"])
    else:
        return None, ["approved_image needs either image or family"]
    if not img:
        return None, [f"Approved RHEL image not found in project {project}"]
    failures = []
    if img.get("status") != "READY":
        failures.append(f"Approved image {img.get('name')} status is {img.get('status')}")
    if (img.get("deprecated") or {}).get("state") in ("DEPRECATED", "OBSOLETE", "DELETED"):
        failures.append(f"Approved image {img.get('name')} is {img['deprecated']['state']}")
    licenses = " ".join(img.get("licenses", [])).lower()
    if "rhel" not in licenses and "red-hat" not in licenses and "rhel" not in img.get("name", ""):
        failures.append(f"Image {img.get('name')} does not look like a RHEL image (no RHEL license)")
    return {
        "project": project, "name": img.get("name"), "self_link": img.get("selfLink"),
        "family": img.get("family"), "disk_size_gb": int(img.get("diskSizeGb") or 0),
        "architecture": img.get("architecture"),
        "guest_os_features": sorted(f.get("type") for f in img.get("guestOsFeatures", [])),
    }, failures


def disk_info(disk: dict, device_name: str | None = None, mode: str | None = None) -> dict:
    return {
        "name": disk.get("name"), "self_link": disk.get("selfLink"), "device_name": device_name,
        "mode": mode, "type": basename(disk.get("type")), "size_gb": int(disk.get("sizeGb") or 0),
        "kms_key": kms_key_name(disk), "architecture": disk.get("architecture"),
        "source_image": disk.get("sourceImage"), "licenses": disk.get("licenses", []),
        "resource_policies": [basename(p) for p in disk.get("resourcePolicies", [])],
        "provisioned_iops": disk.get("provisionedIops"),
        "provisioned_throughput": disk.get("provisionedThroughput"),
    }


def check_permissions(ctx: Ctx, boot: str | None, data_disks: list[str], image: dict | None,
                      for_rollback: bool = False) -> tuple[list[str], list[str]]:
    failures, warnings = [], []
    base = f"{COMPUTE_API}/projects/{ctx.project}/zones/{ctx.zone}"
    checks = [(f"{base}/instances/{ctx.vm}/testIamPermissions", INSTANCE_PERMS, f"instance {ctx.vm}"),
              (f"{CRM_API}/projects/{ctx.project}:testIamPermissions", PROJECT_PERMS, f"project {ctx.project}")]
    if not for_rollback:
        for name in [boot, *data_disks]:
            if name:
                checks.append((f"{base}/disks/{name}/testIamPermissions", SOURCE_DISK_PERMS, f"disk {name}"))
        if image:
            checks.append((f"{COMPUTE_API}/projects/{image['project']}/global/images/{image['name']}/testIamPermissions",
                           IMAGE_PERMS, f"image {image['name']}"))
    for url, perms, what in checks:
        missing = ctx.gc.missing_permissions(url, perms)
        if missing is None:
            (warnings if "image" in what else failures).append(f"Could not verify permissions on {what}")
        elif missing:
            failures.append(f"Missing permissions on {what}: {', '.join(missing)}")
    return failures, warnings


def revalidate(ctx: Ctx, rec: Record) -> dict:
    """Re-check that nothing changed since preparation. Raises PreconditionFailed."""
    doc, failures = rec.doc, []
    inst = ctx.instance()
    if not inst:
        raise PreconditionFailed(["VM no longer exists"])
    if str(inst.get("id")) != doc["vm"]["id"]:
        failures.append(f"VM id changed ({inst.get('id')} != {doc['vm']['id']}); the VM was recreated")
    debian = doc["original_boot_disk"]["name"]
    if boot_disk_name(inst) != debian:
        failures.append(f"Boot disk is {boot_disk_name(inst)}, expected the original Debian disk {debian}")
    hard, soft = diff_baseline(doc["vm"]["baseline"], vm_baseline(inst, ctx.cfg.get("metadata_ignore_keys", [])))
    failures += hard
    for w in soft:
        warn(w)
    rhel_name = doc["rhel_boot_disk"]["name"]
    rhel = ctx.gc.disk(ctx.project, ctx.zone, rhel_name)
    if not rhel:
        failures.append(f"Prepared RHEL disk {rhel_name} no longer exists")
    elif rhel.get("users"):
        failures.append(f"RHEL disk {rhel_name} is attached to {', '.join(basename(u) for u in rhel['users'])}; detach it before cutover")
    for snap in doc.get("snapshots", []):
        s = ctx.gc.snapshot(ctx.project, snap["name"])
        if not s or s.get("status") != "READY":
            failures.append(f"Snapshot {snap['name']} is missing or not READY")
    prepared_at = doc.get("prepared_at")
    if prepared_at:
        age = (ctx.now() - dt.datetime.strptime(prepared_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)).days
        max_age = int(ctx.cfg.get("prepared_max_age_days", 14))
        if age > max_age:
            failures.append(f"Backups were prepared {age} days ago (> {max_age}); start a new migration for fresh backups")
    row, inv_failures = load_inventory_row(ctx)
    failures += inv_failures
    if row and row["classification"] != PATH_CLASSIFICATION[doc["workflow"]]:
        failures.append(f"Inventory classification changed to {row['classification']}")
    if failures:
        raise PreconditionFailed(failures)
    return inst


def enforce_approval(ctx: Ctx, gh_environment: str | None, purpose: str) -> list[dict]:
    """Defence in depth: production gates must show a recorded GitHub approval."""
    approvals = (ctx.approvals_fn(gh_environment) if gh_environment else None) or []
    approved = [a for a in approvals if a.get("state") == "approved"]
    if ctx.environment in ctx.cfg.get("approval_required_for", ["prod"]):
        if not approved:
            raise PreconditionFailed([
                f"{purpose}: no approved review recorded for GitHub environment {gh_environment!r} in this run. "
                f"Configure required reviewers on that environment."])
        if ctx.cfg.get("forbid_self_approval", True):
            trigger = run_context()["triggering_actor"] or run_context()["actor"]
            if all(a.get("user") == trigger for a in approved):
                raise PreconditionFailed([f"{purpose}: the only approval is from the person who triggered the run ({trigger})"])
    return approvals


def detect_os(ctx: Ctx, expect: str) -> tuple[bool, str]:
    """Best-effort guest OS detection: OS inventory first, then serial console output."""
    markers = {"rhel": r"red hat enterprise linux|\"shortname\":\s*\"rhel\"",
               "debian": r"debian gnu/linux 10|\"shortname\":\s*\"debian\"[^}]*\"version\":\s*\"10"}
    other = "debian" if expect == "rhel" else "rhel"
    inventory = ctx.gc.os_inventory(ctx.project, ctx.zone, ctx.vm).lower()
    if inventory and re.search(markers[expect], inventory):
        return True, "OS Config inventory"
    serial = ctx.gc.serial_output(ctx.project, ctx.zone, ctx.vm).lower()
    # The serial buffer can contain earlier boots; trust only the newest OS banner.
    last = {k: max((m.end() for m in re.finditer(markers[k], serial)), default=-1) for k in markers}
    if last[expect] > last[other]:
        return True, "serial console banner"
    return False, ""


def swap_boot_disk(ctx: Ctx, rec: Record, target: str, current: str, device_name: str) -> None:
    """Reconcile the VM to boot from `target`, starting from whatever state it is in now.

    Safe to re-run: each step re-reads the VM and only does what is still needed.
    """
    p, z, vm = ctx.project, ctx.zone, ctx.vm
    inst = ctx.instance()
    if str(inst.get("id")) != rec.doc["vm"]["id"]:
        raise PreconditionFailed(["VM id changed; refusing to touch a different VM"])
    boot = boot_disk_name(inst)
    if boot not in (target, current, None):
        raise PreconditionFailed([f"Unexpected boot disk {boot}; expected {current} or {target}. Manual investigation required."])
    if boot == target and inst.get("status") == "RUNNING":
        log(f"VM already running on {target}; nothing to do")
        return
    if inst.get("status") != "TERMINATED":
        rec.event("VM_STOP", f"Stopping {vm} (status {inst.get('status')})")
        ctx.gc.stop(p, z, vm)
        inst = ctx.instance()
        if inst.get("status") != "TERMINATED":
            raise GcloudError(f"VM did not stop (status {inst.get('status')})")
    if boot == current:
        rec.event("DISK_DETACH", f"Detaching boot disk {current} (retained, not deleted)")
        ctx.gc.detach_disk(p, z, vm, current)
        inst = ctx.instance()
        boot = boot_disk_name(inst)
        if boot is not None:
            raise GcloudError(f"Boot disk still attached after detach: {boot}")
    if boot is None:
        tdisk = ctx.gc.disk(p, z, target)
        if not tdisk:
            raise PreconditionFailed([f"Target boot disk {target} not found"])
        if tdisk.get("users"):
            raise PreconditionFailed([f"Target disk {target} is attached to {tdisk['users']}"])
        rec.event("DISK_ATTACH", f"Attaching {target} as boot disk")
        ctx.gc.attach_boot_disk(p, z, vm, target, device_name)
        inst = ctx.instance()
        if boot_disk_name(inst) != target:
            raise GcloudError(f"Boot disk is {boot_disk_name(inst)} after attach, expected {target}")
    rec.event("VM_START", f"Starting {vm} on {target}")
    ctx.gc.start(p, z, vm)
    inst = ctx.instance()
    if inst.get("status") != "RUNNING":
        raise GcloudError(f"VM did not start (status {inst.get('status')})")


def hold(rec: Record, failures: list[str]) -> None:
    """Record ON_HOLD with the reasons, if the current state allows it."""
    for f in failures:
        error(f)
    if rec.doc and ON_HOLD in TRANSITIONS.get(rec.state, set()):
        rec.transition(ON_HOLD, "; ".join(failures)[:2000], hold_reasons=failures)
    elif rec.doc:
        rec.doc["hold_reasons"] = failures
        rec.event("CHECKS_FAILED", "; ".join(failures)[:2000])


def describe_record(doc: dict) -> str:
    lines = [f"### Migration `{doc['migration_id']}` - **{doc['state']}**", "",
             "| Field | Value |", "|---|---|",
             f"| VM | `{doc['project_id']}/{doc['zone']}/{doc['vm_name']}` ({doc['environment']}) |",
             f"| Workflow | {doc['workflow']} |"]
    if doc.get("original_boot_disk"):
        lines.append(f"| Original Debian boot disk (retained) | `{doc['original_boot_disk']['name']}` |")
    if doc.get("rhel_boot_disk"):
        lines.append(f"| RHEL boot disk | `{doc['rhel_boot_disk']['name']}` |")
    if doc.get("rhel_image"):
        lines.append(f"| RHEL image | `{doc['rhel_image']['project']}/{doc['rhel_image']['name']}` |")
    for snap in doc.get("snapshots", []):
        lines.append(f"| Snapshot ({snap['role']}) | `{snap['name']}` |")
    if doc.get("hold_reasons") and doc["state"] == ON_HOLD:
        lines.append(f"| Hold reasons | {'<br>'.join(doc['hold_reasons'])} |")
    return "\n".join(lines)


# --------------------------------------------------------------------------- commands
def cmd_preflight(ctx: Ctx) -> int:
    path, record = ctx.args.path, not ctx.args.no_record
    failures, warnings = [], []
    rec = ctx.record()

    if rec.doc:
        held_from = rec.doc.get("held_from")
        resumable = rec.state == PRECHECK or (rec.state == ON_HOLD and held_from in (None, PRECHECK))
        if not resumable:
            raise PreconditionFailed([f"Migration {ctx.migration_id} already exists in state {rec.state}"])

    row, inv_failures = load_inventory_row(ctx)
    failures += inv_failures
    if row:
        failures += check_eligibility(ctx, row, path)

    inst = ctx.instance()
    boot = boot_dsk = None
    data = []
    image = None
    if not inst:
        failures.append(f"VM {ctx.vm} not found in {ctx.project}/{ctx.zone}")
    else:
        if inst.get("status") not in ctx.cfg.get("allowed_source_statuses", ["RUNNING", "TERMINATED"]):
            failures.append(f"VM status {inst.get('status')} is not allowed for migration")
        md = {i["key"]: i.get("value", "") for i in (inst.get("metadata") or {}).get("items", [])}
        if "instanceGroupManagers" in md.get("created-by", ""):
            failures.append("VM belongs to a managed instance group; migrate the instance template instead")
        if any(d.get("type") == "SCRATCH" for d in inst.get("disks", [])):
            failures.append("VM has local SSDs, whose data is lost on stop; not supported by this workflow")
        if any(nic.get("accessConfigs") for nic in inst.get("networkInterfaces", [])):
            warnings.append("VM has an external IP; if it is ephemeral it will change on stop/start. Reserve it first if needed.")
        entry = boot_entry(inst)
        boot = basename(entry.get("source")) if entry else None
        if not boot:
            failures.append("VM has no boot disk attached")
        else:
            boot_dsk = ctx.gc.disk(ctx.project, ctx.zone, boot) or {}
            src =" ".join([boot_dsk.get("sourceImage") or "", *boot_dsk.get("licenses", [])]).lower()
            if "rhel" in src or "red-hat" in src:
                failures.append(f"Boot disk {boot} already appears to be RHEL")
            elif "debian-10" not in src and ctx.cfg.get("require_debian10_source", True):
                failures.append(f"Cannot confirm boot disk {boot} is Debian 10 (no debian-10 license or source image)")
            if row and row["boot_disk"] and row["boot_disk"] != boot:
                failures.append(f"Attached boot disk {boot} does not match the inventory boot_disk {row['boot_disk']}")
        for d in data_disk_entries(inst):
            dd = ctx.gc.disk(ctx.project, ctx.zone, basename(d.get("source")))
            if dd:
                data.append(disk_info(dd, d.get("deviceName"), d.get("mode")))
            else:
                failures.append(f"Attached disk {basename(d.get('source'))} could not be read")
        image, img_failures = resolve_image(ctx)
        failures += img_failures
        if image and boot_dsk:
            if image["architecture"] and boot_dsk.get("architecture") and image["architecture"] != boot_dsk["architecture"]:
                failures.append(f"Image architecture {image['architecture']} != disk architecture {boot_dsk['architecture']}")
            if (inst.get("shieldedInstanceConfig") or {}).get("enableSecureBoot") and "UEFI_COMPATIBLE" not in image["guest_os_features"]:
                failures.append("VM has Secure Boot enabled but the RHEL image is not UEFI_COMPATIBLE")
        for key in sorted({kms_key_name(boot_dsk or {}), *(x["kms_key"] for x in data)} - {None}):
            k = ctx.gc.kms_key(key)
            if k is None:
                warnings.append(f"Could not read CMEK key {key}; confirm the Compute Engine service agent can use it")
            elif (k.get("primary") or {}).get("state") not in (None, "ENABLED"):
                failures.append(f"CMEK key {key} primary version is {(k.get('primary') or {}).get('state')}")
        perm_fail, perm_warn = check_permissions(ctx, boot, [x["name"] for x in data], image)
        failures += perm_fail
        warnings += perm_warn

    for other in ctx.store.all_for_vm(ctx.project, ctx.zone, ctx.vm):
        if other.get("migration_id") != ctx.migration_id and other.get("state") in BLOCKING_STATES:
            failures.append(f"VM already has migration {other['migration_id']} in state {other['state']}")

    for w in warnings:
        warn(w)
    summary(f"### Preflight `{ctx.vm}` ({path}) - {'FAILED' if failures else 'PASSED'}\n\n"
            + "\n".join(f"- FAIL: {f}" for f in failures) + ("\n" if failures else "")
            + "\n".join(f"- WARN: {w}" for w in warnings))
    set_output("migration_id", ctx.migration_id)

    if record:
        if not rec.doc:
            rec.doc = {
                "schema_version": SCHEMA_VERSION, "migration_id": ctx.migration_id, "workflow": path,
                "project_id": ctx.project, "zone": ctx.zone, "vm_name": ctx.vm,
                "environment": ctx.environment, "state": None, "created_at": iso(ctx.now()), "history": [],
            }
        if inst and boot_dsk:
            entry = boot_entry(inst)
            rec.doc.update({
                "vm": {"id": str(inst.get("id")), "self_link": inst.get("selfLink"),
                       "original_status": inst.get("status"),
                       "baseline": vm_baseline(inst, ctx.cfg.get("metadata_ignore_keys", []))},
                "original_boot_disk": disk_info(boot_dsk, entry.get("deviceName"), entry.get("mode")),
                "data_disks": data, "rhel_image": image, "assessment": row, "preflight_warnings": warnings,
            })
        if failures:
            if rec.state is None:
                rec.transition(ON_HOLD, "; ".join(failures)[:2000], hold_reasons=failures)
            else:
                hold(rec, failures)
            raise PreconditionFailed(failures)
        rec.transition(PRECHECK, "Preflight passed", hold_reasons=[])
    elif failures:
        raise PreconditionFailed(failures)
    log("Preflight passed")
    return 0


def ensure_snapshot(ctx: Ctx, rec: Record, disk: dict, role: str, suffix: str = "pre-rhel") -> str:
    name = rname(disk["name"], suffix, ctx.migration_id)
    existing = ctx.gc.snapshot(ctx.project, name)
    if existing:
        if (existing.get("labels") or {}).get(f"{ctx.label_prefix}-id") != label_value(ctx.migration_id) \
                or basename(existing.get("sourceDisk")) != disk["name"]:
            raise PreconditionFailed([f"Snapshot {name} exists but belongs to another migration or disk"])
        log(f"Snapshot {name} already exists; reusing")
    else:
        snap_cfg = ctx.cfg.get("snapshot") or {}
        ctx.gc.create_snapshot(
            ctx.project, name, disk["name"], ctx.zone, ctx.labels(role), disk.get("kms_key"),
            snap_cfg.get("storage_location") or None, bool(snap_cfg.get("guest_flush")),
            f"{role} of {disk['name']} ({ctx.migration_id})")
    snaps = [s for s in rec.doc.setdefault("snapshots", []) if s["name"] != name]
    snaps.append({"name": name, "source_disk": disk["name"], "role": role})
    rec.doc["snapshots"] = snaps
    return name


def snapshot_status_in(ctx: Ctx, name: str, statuses: set[str]) -> bool:
    snap = ctx.gc.snapshot(ctx.project, name)
    if snap and snap.get("status") == "FAILED":
        raise GcloudError(f"Snapshot {name} FAILED")
    return bool(snap and snap.get("status") in statuses)


def cmd_prepare(ctx: Ctx) -> int:
    rec = ctx.required_record()
    if rec.state != PRECHECK:
        raise PreconditionFailed([f"prepare requires state PRECHECK, found {rec.state}"])
    doc = rec.doc
    inst = ctx.instance()
    if not inst or str(inst.get("id")) != doc["vm"]["id"] or boot_disk_name(inst) != doc["original_boot_disk"]["name"]:
        hold(rec, ["VM identity or boot disk changed since preflight"])
        return 1

    poll = int(ctx.cfg.get("validation", {}).get("poll_seconds", 30))
    disks = [(doc["original_boot_disk"], "debian-boot-snapshot")] + [(d, "data-disk-snapshot") for d in doc["data_disks"]]
    stopped_by_us = False
    try:
        if ctx.args.stop_vm_for_backup and inst.get("status") == "RUNNING":
            rec.event("VM_STOP", "Stopping VM for consistent backups")
            ctx.gc.stop(ctx.project, ctx.zone, ctx.vm)
            stopped_by_us = True
        names = [ensure_snapshot(ctx, rec, d, role) for d, role in disks]
        rec.save()
        # Disks may be used again once each snapshot has left CREATING.
        for n in names:
            if not ctx.wait_for(f"snapshot {n}", lambda n=n: snapshot_status_in(ctx, n, {"UPLOADING", "READY"}), 3600, poll):
                raise GcloudError(f"Snapshot {n} did not finish creating")
    finally:
        if stopped_by_us:
            rec.event("VM_START", "Restarting VM after backups")
            ctx.gc.start(ctx.project, ctx.zone, ctx.vm)
    for n in names:
        if not ctx.wait_for(f"snapshot {n} READY", lambda n=n: snapshot_status_in(ctx, n, {"READY"}), 7200, poll):
            raise GcloudError(f"Snapshot {n} did not become READY")

    image = doc["rhel_image"]
    debian = doc["original_boot_disk"]
    rhel_name = rname(ctx.vm, "rhel-boot", ctx.migration_id)
    existing = ctx.gc.disk(ctx.project, ctx.zone, rhel_name)
    if existing:
        if (existing.get("labels") or {}).get(f"{ctx.label_prefix}-id") != label_value(ctx.migration_id) \
                or basename(existing.get("sourceImage")) != image["name"]:
            raise PreconditionFailed([f"Disk {rhel_name} exists but was not created by this migration"])
        log(f"RHEL disk {rhel_name} already exists; reusing")
    else:
        ctx.gc.create_disk(
            ctx.project, ctx.zone, rhel_name, image, debian["type"],
            max(debian["size_gb"], image["disk_size_gb"]), ctx.labels("rhel-boot"),
            debian.get("kms_key"), debian.get("resource_policies", []),
            debian.get("provisioned_iops"), debian.get("provisioned_throughput"),
            f"RHEL boot disk for {ctx.vm} ({ctx.migration_id})")
    rhel = ctx.gc.disk(ctx.project, ctx.zone, rhel_name)
    if not rhel or rhel.get("status") != "READY":
        raise GcloudError(f"RHEL disk {rhel_name} is not READY")
    rec.transition(BACKUP_PREPARED, "Snapshots READY and RHEL boot disk created",
                   rhel_boot_disk=disk_info(rhel), prepared_at=iso(ctx.now()))

    if doc["workflow"] == "data":
        rec.transition(WAITING_FOR_DATA_MIGRATION, "Handed off to build team for data migration",
                       handoff={"responsible_team": "build team",
                                "data_migration_plan_ref": (doc.get("assessment") or {}).get("data_migration_plan_ref"),
                                "rhel_disk": rhel_name, "debian_disk": debian["name"]})
        summary(describe_record(rec.doc) + "\n\n**Next:** the build team performs the workload-specific data "
                "migration (the RHEL disk must be detached from any helper VM afterwards), then Cloud Operations "
                f"re-runs **RHEL migration - data** with `phase=cutover` and `migration_id={ctx.migration_id}`.")
    else:
        summary(describe_record(rec.doc))
    set_output("migration_id", ctx.migration_id)
    return 0


def cmd_signoff(ctx: Ctx) -> int:
    rec = ctx.required_record()
    if rec.doc["workflow"] != "data":
        raise PreconditionFailed(["Data-migration sign-off only applies to data-migration workflows"])
    held_from = rec.doc.get("held_from")
    if not (rec.state == WAITING_FOR_DATA_MIGRATION
            or (rec.state == ON_HOLD and held_from in (WAITING_FOR_DATA_MIGRATION, READY_FOR_CUTOVER))):
        raise PreconditionFailed([f"Sign-off requires WAITING_FOR_DATA_MIGRATION, found {rec.state}"])
    ref = (ctx.args.signoff_ref or "").strip()
    if not ref:
        raise PreconditionFailed(["A data-migration sign-off reference (ticket / evidence link) is required"])
    try:
        revalidate(ctx, rec)
        approvals = enforce_approval(ctx, ctx.args.approval_environment, "Data-migration sign-off")
    except PreconditionFailed as exc:
        hold(rec, exc.failures)
        raise
    rec.transition(READY_FOR_CUTOVER, "Data migration signed off",
                   data_migration={"signoff_ref": ref, "recorded_by": run_context()["actor"],
                                   "recorded_at": iso(ctx.now()), "approvals": approvals})
    return 0


def cmd_cutover(ctx: Ctx) -> int:
    rec = ctx.required_record()
    doc, state = rec.doc, rec.state
    if state != CUTOVER_IN_PROGRESS:
        held_from = doc.get("held_from")
        if doc["workflow"] == "data":
            ok = (state == READY_FOR_CUTOVER or (state == ON_HOLD and held_from == READY_FOR_CUTOVER)) \
                and doc.get("data_migration", {}).get("signoff_ref")
        else:
            ok = state in (BACKUP_PREPARED, READY_FOR_CUTOVER) \
                or (state == ON_HOLD and held_from in (BACKUP_PREPARED, READY_FOR_CUTOVER))
        if not ok:
            raise PreconditionFailed([f"Cutover not allowed from state {state} for a {doc['workflow']} migration"])
        try:
            revalidate(ctx, rec)
            approvals = enforce_approval(ctx, ctx.args.approval_environment, "Production cutover")
        except PreconditionFailed as exc:
            hold(rec, exc.failures)
            raise
        if rec.state != READY_FOR_CUTOVER:
            rec.transition(READY_FOR_CUTOVER, "Revalidated and approved")
        doc.setdefault("approvals", {})["cutover"] = approvals
        rec.transition(CUTOVER_IN_PROGRESS, "Replacing boot disk", cutover_started_at=iso(ctx.now()))
    else:
        log("Resuming an interrupted cutover")
    swap_boot_disk(ctx, rec, doc["rhel_boot_disk"]["name"], doc["original_boot_disk"]["name"],
                   doc["original_boot_disk"].get("device_name") or doc["original_boot_disk"]["name"])
    rec.transition(VALIDATION, "VM started on the RHEL boot disk", cutover_completed_at=iso(ctx.now()))
    return 0


def cmd_validate(ctx: Ctx) -> int:
    rollback = ctx.args.mode == "rollback"
    rec = ctx.required_record()
    doc = rec.doc
    want_state = ROLLBACK_VALIDATION if rollback else VALIDATION
    if rec.state != want_state:
        raise PreconditionFailed([f"validate --mode {ctx.args.mode} requires {want_state}, found {rec.state}"])
    vcfg = ctx.cfg.get("validation") or {}
    timeout, poll = int(vcfg.get("timeout_seconds", 900)), int(vcfg.get("poll_seconds", 30))
    expected_boot = doc["original_boot_disk"]["name"] if rollback else doc["rhel_boot_disk"]["name"]
    failures, evidence = [], {}

    inst = ctx.wait_for("VM RUNNING", lambda: (lambda i: i if i and i.get("status") == "RUNNING" else None)(ctx.instance()),
                        timeout, poll)
    if not inst:
        failures.append("VM is not RUNNING")
        inst = ctx.instance() or {}
    if str(inst.get("id")) != doc["vm"]["id"]:
        failures.append("VM id changed")
    if boot_disk_name(inst) != expected_boot:
        failures.append(f"Boot disk is {boot_disk_name(inst)}, expected {expected_boot}")
    hard, soft = diff_baseline(doc["vm"]["baseline"], vm_baseline(inst, ctx.cfg.get("metadata_ignore_keys", [])))
    failures += hard
    for w in soft:
        warn(w)
    if not failures:
        expect = "debian" if rollback else "rhel"
        found = ctx.wait_for(f"{expect} OS banner", lambda: (lambda r: r[1] if r[0] else None)(detect_os(ctx, expect)),
                             timeout, poll)
        if found:
            evidence["os_detected_via"] = found
        elif vcfg.get("os_check", "require") == "require":
            failures.append(f"Could not confirm the guest booted {expect.upper()} within {timeout}s")
        else:
            warn(f"Could not confirm the guest booted {expect.upper()}; os_check=warn so continuing")

    result = {"passed": not failures, "at": iso(ctx.now()), "failures": failures, **evidence}
    if rollback:
        if failures:
            for f in failures:
                error(f)
            rec.transition(ROLLBACK_FAILED, "; ".join(failures)[:2000], rollback_validation=result)
            return 1
        rec.transition(ROLLED_BACK, "VM is running on the original Debian boot disk", rollback_validation=result)
        summary(describe_record(rec.doc) + "\n\n" + DATA_WARNING)
        return 0
    if failures:
        for f in failures:
            error(f)
        rec.transition(FAILED_ROLLBACK_REQUIRED, "; ".join(failures)[:2000], validation=result)
        summary(describe_record(rec.doc) + f"\n\n**Run the RHEL rollback workflow** with `migration_id={ctx.migration_id}`.")
        return 1
    doc["validation"] = result
    rec.event("INFRA_VALIDATION_PASSED", "RHEL boot, disks and VM configuration verified")
    summary(describe_record(rec.doc) + "\n\nInfrastructure validation passed. **Application owner acceptance is still required.**")
    return 0


def cmd_accept(ctx: Ctx) -> int:
    rec = ctx.required_record()
    if rec.state != VALIDATION or not (rec.doc.get("validation") or {}).get("passed"):
        raise PreconditionFailed([f"Acceptance requires state VALIDATION with infrastructure validation passed (state {rec.state})"])
    inst = ctx.instance()
    if not inst or boot_disk_name(inst) != rec.doc["rhel_boot_disk"]["name"]:
        raise PreconditionFailed(["VM is no longer booted from the RHEL disk"])
    approvals = enforce_approval(ctx, ctx.args.approval_environment, "Application acceptance")
    rec.doc.setdefault("approvals", {})["acceptance"] = approvals
    rec.transition(SUCCEEDED, "Application owner accepted the migration", completed_at=iso(ctx.now()))
    summary(describe_record(rec.doc) + "\n\nThe original Debian disk and snapshots are **retained**. "
            "Cleanup is a separate, manually approved change after the retention period.")
    return 0


DATA_WARNING = ("> **Data warning:** rollback restores the original Debian boot disk exactly as it was at cutover. "
                "Changes written to the RHEL boot disk while it was running are NOT carried back (the RHEL disk and its "
                "pre-rollback snapshot are retained for recovery). Attached data disks stay attached throughout, so "
                "their changes are kept. The application owner must run the workload-specific data recovery plan and "
                "post-rollback validation.")


def check_rollback_target(ctx: Ctx, rec: Record) -> dict:
    doc = rec.doc
    if rec.state not in ROLLBACK_ELIGIBLE:
        if rec.state in (PRECHECK, BACKUP_PREPARED, WAITING_FOR_DATA_MIGRATION, READY_FOR_CUTOVER, ON_HOLD):
            raise PreconditionFailed([f"Migration is in {rec.state}: the VM was never cut over, so there is nothing to roll back. "
                                      "The original Debian boot disk is still in place."])
        raise PreconditionFailed([f"Rollback is not allowed from state {rec.state}"])
    inst = ctx.instance()
    if not inst:
        raise PreconditionFailed(["VM no longer exists"])
    if str(inst.get("id")) != doc["vm"]["id"]:
        raise PreconditionFailed(["VM id changed; this is not the VM that was migrated"])
    debian = ctx.gc.disk(ctx.project, ctx.zone, doc["original_boot_disk"]["name"])
    if not debian:
        raise PreconditionFailed([f"Original Debian disk {doc['original_boot_disk']['name']} no longer exists; "
                                  "restore it from snapshot first (manual)"])
    foreign = [u for u in debian.get("users", []) if basename(u) != ctx.vm]
    if foreign:
        raise PreconditionFailed([f"Original Debian disk is attached to another VM: {', '.join(basename(u) for u in foreign)}"])
    boot = boot_disk_name(inst)
    if boot not in (doc["rhel_boot_disk"]["name"], doc["original_boot_disk"]["name"], None):
        raise PreconditionFailed([f"Unexpected boot disk {boot}; manual investigation required"])
    return inst


def cmd_rollback_plan(ctx: Ctx) -> int:
    if ctx.args.confirm_vm_name != ctx.vm:
        raise PreconditionFailed([f"confirm_vm_name ({ctx.args.confirm_vm_name!r}) must exactly match vm_name ({ctx.vm!r})"])
    if not (ctx.args.reason or "").strip():
        raise PreconditionFailed(["A rollback reason is required"])
    rec = ctx.required_record()
    inst = check_rollback_target(ctx, rec)
    perm_fail, _ = check_permissions(ctx, None, [], None, for_rollback=True)
    if perm_fail:
        raise PreconditionFailed(perm_fail)
    doc, boot = rec.doc, boot_disk_name(inst)
    steps = []
    if boot == doc["original_boot_disk"]["name"]:
        steps.append("VM already boots from the Debian disk: ensure it is running, then validate")
    else:
        if inst.get("status") != "TERMINATED":
            steps.append(f"Stop VM `{ctx.vm}` (downtime starts)")
        if boot and ctx.args.snapshot_rhel_disk:
            steps.append(f"Snapshot RHEL disk `{boot}` to preserve post-migration changes")
        if boot:
            steps.append(f"Detach RHEL boot disk `{boot}` (retained, not deleted)")
        steps.append(f"Attach original Debian disk `{doc['original_boot_disk']['name']}` as boot disk")
        steps.append("Start VM, then validate Debian boot and VM configuration")
    rec.event("ROLLBACK_REQUESTED", ctx.args.reason.strip()[:1000], plan=steps, current_boot_disk=boot,
              from_state=rec.state)
    summary(f"### Rollback plan for `{ctx.vm}` (migration `{ctx.migration_id}`, state {rec.state})\n\n"
            + "\n".join(f"{i}. {s}" for i, s in enumerate(steps, 1)) + f"\n\n**Reason:** {ctx.args.reason.strip()}\n\n"
            + DATA_WARNING)
    return 0


def cmd_rollback(ctx: Ctx) -> int:
    rec = ctx.required_record()
    inst = check_rollback_target(ctx, rec)
    doc = rec.doc
    if rec.state != ROLLBACK_IN_PROGRESS:
        approvals = enforce_approval(ctx, ctx.args.approval_environment, "Production rollback")
        doc.setdefault("approvals", {})["rollback"] = approvals
        rec.transition(ROLLBACK_IN_PROGRESS, (ctx.args.reason or "").strip()[:1000],
                       rollback={"reason": (ctx.args.reason or "").strip()[:1000], "started_at": iso(ctx.now()),
                                 "from_state": rec.state})
    rhel = doc["rhel_boot_disk"]["name"]
    if boot_disk_name(inst) == rhel and ctx.args.snapshot_rhel_disk:
        if inst.get("status") != "TERMINATED":
            rec.event("VM_STOP", "Stopping VM before snapshotting the RHEL disk")
            ctx.gc.stop(ctx.project, ctx.zone, ctx.vm)
        name = ensure_snapshot(ctx, rec, {"name": rhel, "kms_key": doc["original_boot_disk"].get("kms_key")},
                               "rhel-pre-rollback-snapshot", suffix="pre-rollback")
        doc["rollback"]["rhel_snapshot"] = name
        rec.save()
        poll = int(ctx.cfg.get("validation", {}).get("poll_seconds", 30))
        if not ctx.wait_for(f"snapshot {name}", lambda: snapshot_status_in(ctx, name, {"UPLOADING", "READY"}), 3600, poll):
            raise GcloudError(f"Snapshot {name} did not finish creating")
    swap_boot_disk(ctx, rec, doc["original_boot_disk"]["name"], rhel,
                   doc["original_boot_disk"].get("device_name") or doc["original_boot_disk"]["name"])
    rec.transition(ROLLBACK_VALIDATION, "VM started on the original Debian boot disk")
    return 0


def cmd_mark_failed(ctx: Ctx) -> int:
    rec = ctx.record()
    if not rec.doc:
        log("No migration record exists for this run; nothing to mark")
        return 0
    note = ctx.args.note or "Workflow job failed or was cancelled"
    state = rec.state
    if ctx.args.stage == "accept" and state == VALIDATION:
        rec.event("ACCEPTANCE_NOT_GIVEN", note + " - VM stays on RHEL in VALIDATION. Re-run the acceptance job, "
                  "or run the rollback workflow.")
    elif state in (CUTOVER_IN_PROGRESS, VALIDATION):
        rec.transition(FAILED_ROLLBACK_REQUIRED, note)
    elif state in (ROLLBACK_IN_PROGRESS, ROLLBACK_VALIDATION):
        rec.transition(ROLLBACK_FAILED, note)
    elif state in (PRECHECK, BACKUP_PREPARED, WAITING_FOR_DATA_MIGRATION, READY_FOR_CUTOVER):
        rec.transition(ON_HOLD, note, hold_reasons=[note])
    else:
        rec.event("RUN_FAILED", note)
    summary(describe_record(rec.doc))
    return 0


def cmd_status(ctx: Ctx) -> int:
    rec = ctx.required_record()
    summary(describe_record(rec.doc))
    print(json.dumps({k: v for k, v in rec.doc.items() if k != "history"}, indent=2))
    return 0


COMMANDS = {
    "preflight": cmd_preflight, "prepare": cmd_prepare, "signoff": cmd_signoff, "cutover": cmd_cutover,
    "validate": cmd_validate, "accept": cmd_accept, "rollback-plan": cmd_rollback_plan,
    "rollback": cmd_rollback, "mark-failed": cmd_mark_failed, "status": cmd_status,
}


# --------------------------------------------------------------------------- CLI
def env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes")


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--config", default=os.environ.get("RHEL_CONFIG", "config/migration-config.json"))
    common.add_argument("--project-id", default=os.environ.get("RHEL_PROJECT_ID"))
    common.add_argument("--zone", default=os.environ.get("RHEL_ZONE"))
    common.add_argument("--vm-name", default=os.environ.get("RHEL_VM_NAME"))
    common.add_argument("--environment", default=os.environ.get("RHEL_ENVIRONMENT"))
    common.add_argument("--migration-id", default=os.environ.get("RHEL_MIGRATION_ID"))
    common.add_argument("--approval-environment", default=os.environ.get("RHEL_APPROVAL_ENVIRONMENT"),
                        help="GitHub environment whose recorded approval gates this step")

    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("preflight", parents=[common], help="Read-only checks; records PRECHECK or ON_HOLD")
    p.add_argument("--path", choices=sorted(PATH_CLASSIFICATION), default=os.environ.get("RHEL_PATH", "standard"))
    p.add_argument("--no-record", action="store_true", help="Run the checks without writing a migration record")
    p = sub.add_parser("prepare", parents=[common], help="Snapshots + RHEL boot disk")
    p.add_argument("--stop-vm-for-backup", action="store_true", default=env_flag("RHEL_STOP_VM_FOR_BACKUP"))
    p = sub.add_parser("signoff", parents=[common], help="Record build-team data-migration sign-off")
    p.add_argument("--signoff-ref", default=os.environ.get("RHEL_SIGNOFF_REF"))
    sub.add_parser("cutover", parents=[common], help="Swap the boot disk to RHEL")
    p = sub.add_parser("validate", parents=[common], help="Validate after cutover or rollback")
    p.add_argument("--mode", choices=["migration", "rollback"], default="migration")
    sub.add_parser("accept", parents=[common], help="Record application-owner acceptance")
    p = sub.add_parser("rollback-plan", parents=[common], help="Read-only rollback checks and plan")
    p.add_argument("--reason", default=os.environ.get("RHEL_ROLLBACK_REASON"))
    p.add_argument("--confirm-vm-name", default=os.environ.get("RHEL_CONFIRM_VM_NAME"))
    p.add_argument("--snapshot-rhel-disk", action=argparse.BooleanOptionalAction,
                   default=os.environ.get("RHEL_SNAPSHOT_RHEL_DISK", "true").lower() != "false")
    p = sub.add_parser("rollback", parents=[common], help="Restore the original Debian boot disk")
    p.add_argument("--reason", default=os.environ.get("RHEL_ROLLBACK_REASON"))
    p.add_argument("--snapshot-rhel-disk", action=argparse.BooleanOptionalAction,
                   default=os.environ.get("RHEL_SNAPSHOT_RHEL_DISK", "true").lower() != "false")
    p = sub.add_parser("mark-failed", parents=[common], help="Failure handler: hold or flag the migration")
    p.add_argument("--stage", default=os.environ.get("RHEL_FAILED_STAGE", "other"))
    p.add_argument("--note", default="")
    sub.add_parser("status", parents=[common], help="Print the migration record")
    return parser


def load_config(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        cfg = {k: v for k, v in json.load(f).items() if not k.startswith("_")}
    if not cfg.get("state_bucket") or "REPLACE" in cfg["state_bucket"]:
        raise PreconditionFailed([f"state_bucket is not configured in {path}"])
    return cfg


def validate_args(args: argparse.Namespace, cfg: dict) -> None:
    if not args.migration_id and args.command == "preflight":
        run_id = os.environ.get("GITHUB_RUN_ID") or utcnow().strftime("%Y%m%d%H%M%S")
        args.migration_id = f"mig-{run_id}"
    failures = []
    for field, pattern in TARGET_PATTERNS.items():
        value = getattr(args, field)
        if not value or not re.fullmatch(pattern, value):
            failures.append(f"Invalid or missing {field}: {value!r}")
    if args.environment not in cfg.get("environments", ["nonprod", "prod"]):
        failures.append(f"Environment {args.environment!r} is not one of {cfg.get('environments')}")
    if failures:
        raise PreconditionFailed(failures)


def main(argv: list[str] | None = None, gc: Gcloud | None = None, **ctx_kwargs) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    args = build_parser().parse_args(argv)
    try:
        cfg = load_config(args.config)
        validate_args(args, cfg)
        ctx = Ctx(args, cfg, gc or Gcloud(), **ctx_kwargs)
        log(f"== {args.command} {args.project_id}/{args.zone}/{args.vm_name} [{args.environment}] {args.migration_id}")
        return COMMANDS[args.command](ctx)
    except PreconditionFailed as exc:
        for f in exc.failures:
            error(f)
        return 1
    except GcloudError as exc:
        error(str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())

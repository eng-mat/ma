"""Offline tests for scripts/rhel_migrate.py.

Runs the real command logic against an in-memory fake of Compute Engine + GCS, so the
standard, data-migration and rollback flows (including failure/resume paths) can be
exercised without a GCP project. Standard library only:

    python -m unittest discover -s tests -v
"""
from __future__ import annotations

import copy
import datetime as dt
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import rhel_migrate as rm  # noqa: E402

P, Z, VM = "demo-project-01", "europe-west2-b", "app-web-01"
API = "https://www.googleapis.com/compute/v1"
NOW = dt.datetime(2026, 10, 22, 12, 0, tzinfo=dt.timezone.utc)


def link(kind, name, zone=Z, project=P):
    return f"{API}/projects/{project}/zones/{zone}/{kind}/{name}"


class FakeGcloud:
    """Just enough Compute Engine + GCS behaviour to drive the workflows."""

    def __init__(self):
        self.instances, self.disks, self.snapshots, self.objects = {}, {}, {}, {}
        self.serial: dict[str, str] = {}
        self.missing_perms: list[str] = []
        self.fail_once: dict[str, Exception] = {}
        self.calls: list[str] = []
        self.images = {("img-project", "rhel-9-v20261001"): {
            "name": "rhel-9-v20261001", "selfLink": f"{API}/projects/img-project/global/images/rhel-9-v20261001",
            "family": "rhel-9-approved", "status": "READY", "diskSizeGb": "20", "architecture": "X86_64",
            "licenses": [f"{API}/projects/rhel-cloud/global/licenses/rhel-9-server"],
            "guestOsFeatures": [{"type": "UEFI_COMPATIBLE"}]}}

    # ---- builders
    def add_disk(self, name, os_name="data", size=50, kms=None):
        d = {"name": name, "selfLink": link("disks", name), "sizeGb": str(size), "status": "READY",
             "type": link("diskTypes", "pd-balanced"), "users": [], "labels": {}, "architecture": "X86_64",
             "_os": os_name}
        if os_name == "debian10":
            d["sourceImage"] = f"{API}/projects/debian-cloud/global/images/debian-10-buster-v20240611"
            d["licenses"] = [f"{API}/projects/debian-cloud/global/licenses/debian-10-buster"]
        if kms:
            d["diskEncryptionKey"] = {"kmsKeyName": kms + "/cryptoKeyVersions/1"}
        self.disks[name] = d
        return d

    def add_vm(self, name=VM, data_disks=(), kms=None):
        boot = self.add_disk(name, "debian10", 10, kms)
        disks = [{"source": boot["selfLink"], "deviceName": name, "boot": True, "type": "PERSISTENT", "mode": "READ_WRITE"}]
        for dd in data_disks:
            self.add_disk(dd)
            disks.append({"source": link("disks", dd), "deviceName": dd, "boot": False, "type": "PERSISTENT", "mode": "READ_WRITE"})
        for d in disks:
            self.disks[rm.basename(d["source"])]["users"] = [link("instances", name)]
        self.instances[name] = {
            "id": "1234567890", "name": name, "selfLink": link("instances", name), "status": "RUNNING",
            "machineType": link("machineTypes", "e2-standard-2"), "disks": disks,
            "serviceAccounts": [{"email": "vm-sa@demo.iam.gserviceaccount.com", "scopes": ["cloud-platform"]}],
            "tags": {"items": ["web"]}, "labels": {"app": "web"},
            "metadata": {"items": [{"key": "startup-script", "value": "secret-ish"}]},
            "networkInterfaces": [{"network": "global/networks/shared", "subnetwork": "regions/x/subnetworks/app",
                                   "networkIP": "10.0.0.5"}],
            "shieldedInstanceConfig": {"enableSecureBoot": True},
        }
        self._boot_banner(name)

    def _boot_banner(self, vm):
        os_name = self.disks[rm.basename(rm.boot_entry(self.instances[vm])["source"])]["_os"]
        banner = {"debian10": "Debian GNU/Linux 10 host ttyS0\nhost login:",
                  "rhel": "Red Hat Enterprise Linux 9.4 (Plow)\nhost login:"}.get(os_name, "kernel panic")
        self.serial[vm] = self.serial.get(vm, "") + "\n" + banner

    def _call(self, name):
        self.calls.append(name)
        if name in self.fail_once:
            raise self.fail_once.pop(name)

    # ---- reads
    def instance(self, p, z, n):
        return copy.deepcopy(self.instances.get(n))

    def disk(self, p, z, n):
        return copy.deepcopy(self.disks.get(n))

    def snapshot(self, p, n):
        return copy.deepcopy(self.snapshots.get(n))

    def image(self, project, name=None, family=None):
        for (proj, img_name), img in self.images.items():
            if proj == project and (img_name == name or img["family"] == family):
                return copy.deepcopy(img)
        return None

    def kms_key(self, key):
        return {"primary": {"state": "ENABLED"}}

    def serial_output(self, p, z, n):
        return self.serial.get(n, "")

    def os_inventory(self, p, z, n):
        return ""

    def missing_permissions(self, url, perms):
        return [x for x in perms if x in self.missing_perms]

    # ---- writes
    def stop(self, p, z, n):
        self._call("stop")
        self.instances[n]["status"] = "TERMINATED"

    def start(self, p, z, n):
        self._call("start")
        inst = self.instances[n]
        assert rm.boot_entry(inst), "cannot start without a boot disk"
        inst["status"] = "RUNNING"
        self._boot_banner(n)

    def detach_disk(self, p, z, n, disk):
        self._call("detach_disk")
        inst = self.instances[n]
        entry = next(d for d in inst["disks"] if rm.basename(d["source"]) == disk)
        assert not entry["boot"] or inst["status"] == "TERMINATED", "boot disk detach needs a stopped VM"
        inst["disks"].remove(entry)
        self.disks[disk]["users"] = []

    def attach_boot_disk(self, p, z, n, disk, device_name):
        self._call("attach_boot_disk")
        inst = self.instances[n]
        assert inst["status"] == "TERMINATED" and not rm.boot_entry(inst)
        assert not self.disks[disk]["users"], "disk already in use"
        inst["disks"].insert(0, {"source": link("disks", disk), "deviceName": device_name, "boot": True,
                                 "type": "PERSISTENT", "mode": "READ_WRITE"})
        self.disks[disk]["users"] = [link("instances", n)]

    def create_snapshot(self, project, name, source_disk, zone, labels, kms_key, storage_location, guest_flush, description):
        self._call("create_snapshot")
        assert name not in self.snapshots
        self.snapshots[name] = {"name": name, "status": "READY", "labels": labels,
                                "sourceDisk": link("disks", source_disk), "_kms": kms_key}

    def create_disk(self, project, zone, name, image, disk_type, size_gb, labels, kms_key, resource_policies,
                    provisioned_iops, provisioned_throughput, description):
        self._call("create_disk")
        assert name not in self.disks
        d = self.add_disk(name, "rhel", size_gb)
        d.update(labels=labels, sourceImage=image["self_link"], licenses=["rhel-9-server"])
        if kms_key:
            d["diskEncryptionKey"] = {"kmsKeyName": kms_key}

    # ---- GCS
    def storage_read(self, url):
        if url not in self.objects:
            return None, 0
        text, gen = self.objects[url]
        return json.loads(text), gen

    def storage_write(self, url, doc, if_generation):
        current = self.objects.get(url, (None, 0))[1]
        if current != if_generation:
            raise rm.Conflict(f"412 generation {current} != {if_generation}")
        self.objects[url] = (json.dumps(doc), current + 1)
        return current + 1

    def storage_list(self, prefix):
        return [u for u in self.objects if u.startswith(prefix)]


class Harness(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.inventory = os.path.join(self.tmp.name, "inv.csv")
        self.config = os.path.join(self.tmp.name, "cfg.json")
        self.cfg = {
            "state_bucket": "state-bucket", "inventory_path": self.inventory,
            "approved_image": {"project": "img-project", "family": "rhel-9-approved"},
            "environments": ["nonprod", "prod"], "approval_required_for": ["prod"],
            "validation": {"timeout_seconds": 0, "poll_seconds": 0, "os_check": "require"},
        }
        self.write_config()
        self.gc = FakeGcloud()
        self.approvals: dict[str, list] = {}
        self.write_inventory("STANDARD")
        for var in ("GITHUB_OUTPUT", "GITHUB_STEP_SUMMARY", "GITHUB_ACTOR", "GITHUB_TRIGGERING_ACTOR"):
            os.environ.pop(var, None)

    def tearDown(self):
        self.tmp.cleanup()

    def write_config(self):
        with open(self.config, "w") as f:
            json.dump(self.cfg, f)

    def write_inventory(self, classification, vm=VM, date="2026-10-20", env="nonprod", boot=None, plan="CHG001"):
        with open(self.inventory, "w", newline="") as f:
            f.write(",".join(rm.INVENTORY_COLUMNS) + "\n")
            f.write(f"{P},{Z},{vm},{env},{boot or vm},{classification},{date},build@x,owner@x,owner@x,{plan}\n")

    def run_cmd(self, *argv, env="nonprod", mig="mig-1001"):
        args = [argv[0], "--config", self.config, "--project-id", P, "--zone", Z, "--vm-name", VM,
                "--environment", env, "--migration-id", mig, *argv[1:]]
        return rm.main(args, gc=self.gc, approvals_fn=lambda e: self.approvals.get(e, []),
                       now_fn=lambda: NOW, sleep_fn=lambda s: None)

    def doc(self, mig="mig-1001"):
        url = f"gs://state-bucket/rhel-migrations/{P}/{Z}/{VM}/{mig}.json"
        return self.gc.storage_read(url)[0]

    def boot(self):
        return rm.boot_disk_name(self.gc.instances[VM])

    def migrate_standard(self, env="nonprod"):
        self.assertEqual(self.run_cmd("preflight", "--path", "standard", env=env), 0)
        self.assertEqual(self.run_cmd("prepare", env=env), 0)
        self.assertEqual(self.run_cmd("cutover", "--approval-environment", f"rhel-{env}-cutover", env=env), 0)
        self.assertEqual(self.run_cmd("validate", env=env), 0)


class StandardFlow(Harness):
    def test_happy_path_and_retention(self):
        self.gc.add_vm(data_disks=["app-web-01-data"])
        self.migrate_standard()
        self.assertEqual(self.run_cmd("accept"), 0)
        doc = self.doc()
        self.assertEqual(doc["state"], rm.SUCCEEDED)
        self.assertEqual(self.boot(), doc["rhel_boot_disk"]["name"])
        self.assertEqual(self.gc.instances[VM]["status"], "RUNNING")
        # Debian disk retained, detached; data disk still attached; snapshots for both disks.
        self.assertIn(VM, self.gc.disks)
        self.assertEqual(self.gc.disks[VM]["users"], [])
        self.assertTrue(self.gc.disks["app-web-01-data"]["users"])
        self.assertEqual({s["role"] for s in doc["snapshots"]}, {"debian-boot-snapshot", "data-disk-snapshot"})
        self.assertEqual([h["to"] for h in doc["history"] if h["event"] == "STATE_CHANGE"],
                         [rm.PRECHECK, rm.BACKUP_PREPARED, rm.READY_FOR_CUTOVER, rm.CUTOVER_IN_PROGRESS,
                          rm.VALIDATION, rm.SUCCEEDED])
        self.assertNotIn("secret-ish", json.dumps(doc), "metadata values must never be stored")

    def test_prepare_is_idempotent(self):
        self.gc.add_vm()
        self.assertEqual(self.run_cmd("preflight", "--path", "standard"), 0)
        self.gc.fail_once["create_disk"] = rm.GcloudError("quota exceeded")
        self.assertEqual(self.run_cmd("prepare"), 1)
        self.assertEqual(self.run_cmd("mark-failed"), 0)
        self.assertEqual(self.doc()["state"], rm.ON_HOLD)
        # Re-run of the same run: preflight resumes the record, prepare reuses the snapshot.
        self.assertEqual(self.run_cmd("preflight", "--path", "standard"), 0)
        self.assertEqual(self.run_cmd("prepare"), 0)
        self.assertEqual(self.gc.calls.count("create_snapshot"), 1)
        self.assertEqual(self.doc()["state"], rm.BACKUP_PREPARED)

    def test_prod_cutover_requires_recorded_approval(self):
        self.gc.add_vm()
        self.write_inventory("STANDARD", env="prod")
        self.assertEqual(self.run_cmd("preflight", "--path", "standard", env="prod"), 0)
        self.assertEqual(self.run_cmd("prepare", env="prod"), 0)
        self.assertEqual(self.run_cmd("cutover", "--approval-environment", "rhel-prod-cutover", env="prod"), 1)
        self.assertEqual(self.doc()["state"], rm.ON_HOLD)
        self.assertEqual(self.boot(), VM, "VM must not be touched without approval")
        self.approvals["rhel-prod-cutover"] = [{"user": "approver", "state": "approved"}]
        self.assertEqual(self.run_cmd("cutover", "--approval-environment", "rhel-prod-cutover", env="prod"), 0)
        self.assertEqual(self.doc()["approvals"]["cutover"][0]["user"], "approver")

    def test_self_approval_rejected_in_prod(self):
        self.gc.add_vm()
        self.write_inventory("STANDARD", env="prod")
        os.environ["GITHUB_ACTOR"] = "alice"
        self.approvals["rhel-prod-cutover"] = [{"user": "alice", "state": "approved"}]
        self.run_cmd("preflight", "--path", "standard", env="prod")
        self.run_cmd("prepare", env="prod")
        self.assertEqual(self.run_cmd("cutover", "--approval-environment", "rhel-prod-cutover", env="prod"), 1)
        os.environ.pop("GITHUB_ACTOR")

    def test_validation_failure_requires_rollback(self):
        self.gc.add_vm()
        self.run_cmd("preflight", "--path", "standard")
        self.run_cmd("prepare")
        self.run_cmd("cutover")
        self.gc.serial[VM] += "\nkernel panic"  # RHEL banner never appears after the latest boot
        self.gc.serial[VM] = self.gc.serial[VM].replace("Red Hat Enterprise Linux", "boot failure")
        self.assertEqual(self.run_cmd("validate"), 1)
        self.assertEqual(self.doc()["state"], rm.FAILED_ROLLBACK_REQUIRED)
        self.assertEqual(self.run_cmd("accept"), 1)


class Preflight(Harness):
    def preflight_fails_with(self, fragment, path="standard"):
        self.assertEqual(self.run_cmd("preflight", "--path", path), 1)
        doc = self.doc()
        self.assertEqual(doc["state"], rm.ON_HOLD)
        self.assertTrue(any(fragment in r for r in doc["hold_reasons"]), doc["hold_reasons"])

    def test_not_in_inventory(self):
        self.gc.add_vm()
        self.write_inventory("STANDARD", vm="other-vm")
        self.preflight_fails_with("not in the approved inventory")

    def test_wrong_classification(self):
        self.gc.add_vm()
        self.write_inventory("DATA_MIGRATION_REQUIRED")
        self.preflight_fails_with("requires STANDARD")

    def test_on_hold_classification(self):
        self.gc.add_vm()
        self.write_inventory("ON_HOLD")
        self.preflight_fails_with("classification is ON_HOLD")

    def test_stale_assessment(self):
        self.gc.add_vm()
        self.write_inventory("STANDARD", date="2026-01-01")
        self.preflight_fails_with("stale")

    def test_boot_disk_mismatch(self):
        self.gc.add_vm()
        self.write_inventory("STANDARD", boot="some-other-disk")
        self.preflight_fails_with("does not match the inventory")

    def test_missing_permission(self):
        self.gc.add_vm()
        self.gc.missing_perms = ["compute.instances.detachDisk"]
        self.preflight_fails_with("compute.instances.detachDisk")

    def test_non_debian_source(self):
        self.gc.add_vm()
        del self.gc.disks[VM]["licenses"], self.gc.disks[VM]["sourceImage"]
        self.preflight_fails_with("Cannot confirm boot disk")

    def test_second_migration_blocked(self):
        self.gc.add_vm()
        self.assertEqual(self.run_cmd("preflight", "--path", "standard"), 0)
        self.assertEqual(self.run_cmd("preflight", "--path", "standard", mig="mig-2002"), 1)
        self.assertEqual(self.doc("mig-2002")["state"], rm.ON_HOLD)

    def test_no_record_mode_writes_nothing(self):
        self.gc.add_vm()
        self.assertEqual(self.run_cmd("preflight", "--path", "standard", "--no-record"), 0)
        self.assertEqual(self.gc.objects, {})

    def test_bad_input_rejected(self):
        self.assertEqual(rm.main(["status", "--config", self.config, "--project-id", "x; rm -rf /", "--zone", Z,
                                  "--vm-name", VM, "--environment", "nonprod", "--migration-id", "mig-1"],
                                 gc=self.gc), 1)


class DataFlow(Harness):
    def setUp(self):
        super().setUp()
        self.write_inventory("DATA_MIGRATION_REQUIRED")
        self.gc.add_vm(data_disks=["app-db-01-data"])

    def test_signoff_gate_and_cutover(self):
        self.assertEqual(self.run_cmd("preflight", "--path", "data"), 0)
        self.assertEqual(self.run_cmd("prepare"), 0)
        self.assertEqual(self.doc()["state"], rm.WAITING_FOR_DATA_MIGRATION)
        self.assertEqual(self.boot(), VM, "Debian VM stays untouched while data is migrated")
        self.assertEqual(self.run_cmd("cutover"), 1, "cutover without sign-off must be refused")
        self.assertEqual(self.run_cmd("signoff", "--signoff-ref", ""), 1)
        self.assertEqual(self.run_cmd("signoff", "--signoff-ref", "CHG001 evidence"), 0)
        self.assertEqual(self.doc()["state"], rm.READY_FOR_CUTOVER)
        self.assertEqual(self.run_cmd("cutover"), 0)
        self.assertEqual(self.run_cmd("validate"), 0)
        self.assertEqual(self.run_cmd("accept"), 0)
        self.assertEqual(self.doc()["data_migration"]["signoff_ref"], "CHG001 evidence")

    def test_drift_during_data_migration_holds(self):
        self.run_cmd("preflight", "--path", "data")
        self.run_cmd("prepare")
        # Build team leaves the RHEL disk attached to a helper VM.
        rhel = self.doc()["rhel_boot_disk"]["name"]
        self.gc.disks[rhel]["users"] = [link("instances", "helper-vm")]
        self.assertEqual(self.run_cmd("signoff", "--signoff-ref", "CHG001"), 1)
        doc = self.doc()
        self.assertEqual((doc["state"], doc["held_from"]), (rm.ON_HOLD, rm.WAITING_FOR_DATA_MIGRATION))
        # Fixed: detached again -> sign-off may resume from ON_HOLD.
        self.gc.disks[rhel]["users"] = []
        self.assertEqual(self.run_cmd("signoff", "--signoff-ref", "CHG001"), 0)

    def test_config_change_holds(self):
        self.run_cmd("preflight", "--path", "data")
        self.run_cmd("prepare")
        self.gc.instances[VM]["tags"]["items"].append("new-firewall-tag")
        self.assertEqual(self.run_cmd("signoff", "--signoff-ref", "CHG001"), 1)
        self.assertTrue(any("tags" in r for r in self.doc()["hold_reasons"]))


class Rollback(Harness):
    def rollback(self, *extra, env="nonprod"):
        base = ["--reason", "App owner rejected", "--approval-environment", f"rhel-{env}-rollback", *extra]
        self.assertEqual(self.run_cmd("rollback-plan", "--confirm-vm-name", VM, *base, env=env), 0)
        self.assertEqual(self.run_cmd("rollback", *base, env=env), 0)
        self.assertEqual(self.run_cmd("validate", "--mode", "rollback", env=env), 0)

    def test_rollback_after_success(self):
        self.gc.add_vm(data_disks=["app-web-01-data"])
        self.migrate_standard()
        self.run_cmd("accept")
        rhel = self.doc()["rhel_boot_disk"]["name"]
        self.rollback()
        doc = self.doc()
        self.assertEqual(doc["state"], rm.ROLLED_BACK)
        self.assertEqual(self.boot(), VM)
        self.assertEqual(self.gc.instances[VM]["status"], "RUNNING")
        self.assertIn(rhel, self.gc.disks, "RHEL disk retained after rollback")
        self.assertTrue(any(s["role"] == "rhel-pre-rollback-snapshot" for s in doc["snapshots"]))
        self.assertTrue(self.gc.disks["app-web-01-data"]["users"])
        self.assertTrue(any(h["event"] == "ROLLBACK_REQUESTED" for h in doc["history"]))

    def test_rollback_from_interrupted_cutover(self):
        self.gc.add_vm()
        self.run_cmd("preflight", "--path", "standard")
        self.run_cmd("prepare")
        self.gc.fail_once["attach_boot_disk"] = rm.GcloudError("backend error")
        self.assertEqual(self.run_cmd("cutover"), 1)
        self.assertIsNone(self.boot(), "VM is left with no boot disk")
        self.run_cmd("mark-failed")
        self.assertEqual(self.doc()["state"], rm.FAILED_ROLLBACK_REQUIRED)
        self.rollback()
        self.assertEqual(self.boot(), VM)
        self.assertEqual(self.doc()["state"], rm.ROLLED_BACK)

    def test_rollback_job_rerun_resumes(self):
        self.gc.add_vm()
        self.migrate_standard()
        self.gc.fail_once["start"] = rm.GcloudError("zone resource exhausted")
        self.run_cmd("rollback-plan", "--confirm-vm-name", VM, "--reason", "r")
        self.assertEqual(self.run_cmd("rollback", "--reason", "r"), 1)
        self.assertEqual(self.doc()["state"], rm.ROLLBACK_IN_PROGRESS)
        self.assertEqual(self.run_cmd("rollback", "--reason", "r"), 0)
        self.assertEqual(self.gc.calls.count("create_snapshot"), 2, "boot snapshot + one pre-rollback snapshot")
        self.assertEqual(self.run_cmd("validate", "--mode", "rollback"), 0)

    def test_prod_rollback_requires_approval(self):
        self.write_inventory("STANDARD", env="prod")
        self.gc.add_vm()
        self.approvals["rhel-prod-cutover"] = [{"user": "approver", "state": "approved"}]
        self.migrate_standard(env="prod")
        self.run_cmd("rollback-plan", "--confirm-vm-name", VM, "--reason", "r", env="prod")
        self.assertEqual(self.run_cmd("rollback", "--reason", "r", "--approval-environment", "rhel-prod-rollback",
                                      env="prod"), 1)
        self.assertNotEqual(self.boot(), VM)
        self.approvals["rhel-prod-rollback"] = [{"user": "change-approver", "state": "approved"}]
        self.rollback(env="prod")

    def test_confirm_name_must_match(self):
        self.gc.add_vm()
        self.migrate_standard()
        self.assertEqual(self.run_cmd("rollback-plan", "--confirm-vm-name", "app-web-02", "--reason", "r"), 1)

    def test_nothing_to_roll_back_before_cutover(self):
        self.gc.add_vm()
        self.run_cmd("preflight", "--path", "standard")
        self.run_cmd("prepare")
        self.assertEqual(self.run_cmd("rollback-plan", "--confirm-vm-name", VM, "--reason", "r"), 1)

    def test_rolled_back_vm_can_be_migrated_again(self):
        self.gc.add_vm()
        self.migrate_standard()
        self.rollback()
        self.assertEqual(self.run_cmd("preflight", "--path", "standard", mig="mig-3003"), 0)


class Helpers(unittest.TestCase):
    def test_rname_is_valid_and_bounded(self):
        name = rm.rname("a" * 63, "rhel-boot", "mig-123456789012")
        self.assertLessEqual(len(name), 63)
        self.assertRegex(name, r"^[a-z]([-a-z0-9]*[a-z0-9])?$")
        self.assertEqual(rm.rname("9vm", "x"), "r-9vm-x")

    def test_every_state_has_transitions(self):
        for targets in rm.TRANSITIONS.values():
            for t in targets:
                self.assertIn(t, rm.TRANSITIONS)


if __name__ == "__main__":
    unittest.main()

# Debian 10 → RHEL migration automation (GitHub Actions + GCP)

Implements the design in [`docs/debian10_to_rhel_migration_automation_design_v2.docx`](docs/debian10_to_rhel_migration_automation_design_v2.docx):
three one-VM-per-run workflows that share one Python script.

> **Status: DRAFT for non-prod testing.** Logic is covered by offline tests against a simulated GCP. Before any
> production use, Cloud Engineering must validate the gcloud behaviour, CMEK settings, Terraform interaction and
> the rollback procedure on non-prod VMs (see [Before production](#before-production)).

| Workflow | File | When |
|---|---|---|
| A – Standard migration | `.github/workflows/rhel-standard-migration.yml` | Inventory classification `STANDARD` (no data transfer) |
| B – Data migration | `.github/workflows/rhel-data-migration.yml` | Classification `DATA_MIGRATION_REQUIRED`; two runs: `prepare`, then `cutover` after build-team sign-off |
| C – Rollback | `.github/workflows/rhel-rollback.yml` | Any time after cutover (failed **or** succeeded): back to the original Debian boot disk |

## Package layout

```
.github/
  actions/gcp-setup/action.yml        WIF auth + gcloud + Python (shared by every job)
  workflows/rhel-standard-migration.yml
  workflows/rhel-data-migration.yml
  workflows/rhel-rollback.yml
scripts/
  rhel_migrate.py                     shared logic: preflight, prepare, signoff, cutover, validate,
                                      accept, rollback-plan, rollback, mark-failed, status
  setup-github-environments.sh        creates the 10 GitHub environments
config/migration-config.json          approved image, state bucket, thresholds
inventory/vm_inventory.csv            approved VM inventory / eligibility (change via reviewed PR)
iam/rhel-migrator-role.yaml           least-privilege custom role (no delete permissions)
tests/test_rhel_migrate.py            offline tests (in-memory fake GCP)
docs/                                 design document v2 (with rollback workflow)
```

## How the flows work

```
A  Standard     prepare ─▶ [cutover approval] ─▶ cutover ─▶ validate ─▶ [app acceptance] ─▶ SUCCEEDED
B  Data, run 1  prepare ─▶ WAITING_FOR_DATA_MIGRATION   (run ends; build team migrates data + evidence)
B  Data, run 2  [data sign-off] ─▶ [cutover approval] ─▶ cutover ─▶ validate ─▶ [app acceptance] ─▶ SUCCEEDED
C  Rollback     plan ─▶ [rollback approval] ─▶ rollback ─▶ validate ─▶ ROLLED_BACK
```

`[...]` = GitHub environment with required reviewers (prod). Every gated step **also** checks in code that an
approval was recorded for that environment in the run (prod), and rejects self-approval, so a misconfigured
environment fails closed.

* **prepare** – preflight (inventory eligibility, assessment age, VM/boot-disk identity, Debian 10 source, MIG and
  local-SSD exclusions, image READY/arch/Secure Boot, CMEK key, IAM permissions, no other active migration) →
  snapshots of boot + data disks (same CMEK key) → new RHEL boot disk from the approved image (same type, size ≥
  original, same CMEK key and snapshot schedule) → records the VM configuration baseline.
* **cutover** – re-validates (VM id, boot disk, config baseline, RHEL disk detached, snapshots READY, backup age,
  inventory) → stop → detach Debian disk (**kept**) → attach RHEL disk as boot (same device name) → start.
  The swap is *reconciling*: re-running after a failure continues from the VM's actual state.
* **validate** – VM RUNNING on the expected boot disk, config baseline unchanged, guest OS banner confirmed
  (OS Config inventory, else serial console). Application validation is the owner's acceptance gate.
* **rollback** – (optional, default on) snapshot the RHEL disk while stopped → detach RHEL disk (**kept**) →
  attach the original Debian disk as boot → start → validate Debian boot + config.

Nothing is ever deleted. The custom IAM role has no delete permissions at all.

### ⚠️ Rollback and data

Restoring the Debian boot disk **does not reverse data changes made while the VM ran RHEL**. Data written to the
RHEL boot disk stays on the (retained, snapshotted) RHEL disk; attached data disks stay attached throughout, so
their changes are kept and may need to be reconciled. Each workload needs a data-recovery plan, and the
application owner must validate after rollback.

### States

`PRECHECK → BACKUP_PREPARED → (WAITING_FOR_DATA_MIGRATION →) READY_FOR_CUTOVER → CUTOVER_IN_PROGRESS → VALIDATION → SUCCEEDED`
Failure before cutover → `ON_HOLD` (no cutover allowed; resumable after the cause is fixed).
Failure during/after cutover → `FAILED_ROLLBACK_REQUIRED` (only exit is the rollback workflow).
Rollback: `ROLLBACK_IN_PROGRESS → ROLLBACK_VALIDATION → ROLLED_BACK` (or `ROLLBACK_FAILED`, re-runnable).
If acceptance is not given (rejected/timed out) the VM stays in `VALIDATION` on RHEL: re-run the acceptance job or
run the rollback.

Each migration is one JSON record in GCS: `gs://BUCKET/rhel-migrations/PROJECT/ZONE/VM/MIGRATION_ID.json`, with a
full history (who, when, run URL, approvals, resource IDs). Writes use generation preconditions; metadata values
are only stored as a hash.

## One-time setup

1. **Repository** – copy this folder into the infrastructure repo (keep the `.github/` paths). Protect the default
   branch and add CODEOWNERS for `inventory/`, `config/` and `scripts/` (Cloud Engineering + Cloud Operations).

2. **State bucket** (in an admin project):
   ```bash
   gcloud storage buckets create gs://ORG-rhel-migration-state --project=ADMIN_PROJECT --location=REGION \
     --uniform-bucket-level-access --public-access-prevention
   gcloud storage buckets update gs://ORG-rhel-migration-state --versioning
   ```
   Versioning keeps every prior version of each record for audit. Add a retention policy if required.

3. **Service account + Workload Identity Federation** (no JSON keys):
   ```bash
   gcloud iam service-accounts create rhel-migrator --project=ADMIN_PROJECT
   gcloud iam workload-identity-pools create github --project=ADMIN_PROJECT --location=global
   gcloud iam workload-identity-pools providers create-oidc github-actions --project=ADMIN_PROJECT \
     --location=global --workload-identity-pool=github --issuer-uri=https://token.actions.githubusercontent.com \
     --attribute-mapping="google.subject=assertion.sub,attribute.repository=assertion.repository,attribute.environment=assertion.environment,attribute.ref=assertion.ref" \
     --attribute-condition="assertion.repository=='ORG/REPO' && assertion.ref=='refs/heads/main' && assertion.environment.startsWith('rhel-')"
   gcloud iam service-accounts add-iam-policy-binding rhel-migrator@ADMIN_PROJECT.iam.gserviceaccount.com \
     --project=ADMIN_PROJECT --role=roles/iam.workloadIdentityUser \
     --member="principalSet://iam.googleapis.com/projects/ADMIN_PROJECT_NUMBER/locations/global/workloadIdentityPools/github/attribute.repository/ORG/REPO"
   ```
   Use your organisation's existing pool/provider if one is mandated. A separate prod service account can be
   bound to `attribute.environment` values `rhel-prod*` only.

4. **IAM** – create the custom role from `iam/rhel-migrator-role.yaml` and grant it on each VM project; grant
   `roles/compute.imageUser` on the approved-image project and `roles/storage.objectUser` on the state bucket.

5. **GitHub environments** – `bash scripts/setup-github-environments.sh ORG/REPO`, then add required reviewers to
   `rhel-prod-cutover`, `rhel-prod-data-signoff`, `rhel-prod-acceptance`, `rhel-prod-rollback` and tick
   *Prevent self-review*.

6. **Repository variables** (Settings → Variables): `GCP_WIF_PROVIDER`
   (`projects/NUMBER/locations/global/workloadIdentityPools/github/providers/github-actions`) and
   `GCP_MIGRATION_SERVICE_ACCOUNT`. Override per environment if prod uses a different service account.

7. **Config** – edit `config/migration-config.json`:

   | Key | Meaning |
   |---|---|
   | `state_bucket`, `state_prefix` | Where migration records live |
   | `approved_image.project` + `image` **or** `family` | Approved RHEL image. Pinning `image` is preferred; a family is resolved once at prepare and recorded |
   | `approval_required_for` | Environments whose gates must show a recorded approval (default `prod`) |
   | `forbid_self_approval` | Reject a gate approved only by the person who triggered the run |
   | `assessment_max_age_days` | Max age of the guest assessment in the inventory |
   | `prepared_max_age_days` | Max age of backups/RHEL disk at cutover (data path waits) |
   | `require_debian10_source` | Refuse boot disks not provably Debian 10 (license / source image) |
   | `metadata_ignore_keys` | Metadata keys excluded from the drift check (e.g. `ssh-keys`) |
   | `snapshot.storage_location`, `snapshot.guest_flush` | Snapshot location; app-consistent flush (needs guest agent support) |
   | `validation.timeout_seconds`, `poll_seconds`, `os_check` | Boot validation; `os_check` `require` or `warn` |

8. **Inventory** – maintain `inventory/vm_inventory.csv` (one row per VM, changes via reviewed PR):
   `project_id, zone, vm_name, environment, boot_disk, classification (STANDARD | DATA_MIGRATION_REQUIRED | ON_HOLD),
   assessment_date (YYYY-MM-DD), assessment_owner, app_owner, validation_owner, data_migration_plan_ref, notes`.
   Missing, duplicate, stale or mismatched rows hold the VM.

## Running

From the Actions tab (*Run workflow*) or the CLI:

```bash
# A - standard
gh workflow run rhel-standard-migration.yml -f project_id=my-proj -f zone=europe-west2-b -f vm_name=app-web-01 -f environment=nonprod

# B - data migration, run 1 (note the migration ID in the run summary)
gh workflow run rhel-data-migration.yml -f phase=prepare -f project_id=my-proj -f zone=europe-west2-b -f vm_name=app-db-01 -f environment=nonprod
# B - run 2, after the build team has migrated and verified the data
gh workflow run rhel-data-migration.yml -f phase=cutover -f migration_id=mig-1234567890 -f data_migration_signoff_ref=CHG0012345 -f project_id=my-proj -f zone=europe-west2-b -f vm_name=app-db-01 -f environment=nonprod

# C - rollback
gh workflow run rhel-rollback.yml -f migration_id=mig-1234567890 -f reason="App owner found regression" -f confirm_vm_name=app-web-01 -f project_id=my-proj -f zone=europe-west2-b -f vm_name=app-web-01 -f environment=nonprod
```

Data path note: the RHEL disk is created unattached. If the build team attaches it to a helper VM to stage data,
they must detach it again before run 2 — cutover refuses a RHEL disk that is in use. Any change to the Debian VM's
configuration (disks, tags, service account, network, metadata) between the runs also holds the migration;
start a fresh `prepare` run in that case.

Read-only checks for a VM without recording anything (locally, with your own gcloud login):

```bash
python scripts/rhel_migrate.py preflight --path standard --no-record --project-id my-proj --zone europe-west2-b --vm-name app-web-01 --environment nonprod
```

## Testing

```bash
python -m unittest discover -s tests -v
```

The 27 tests run the real command logic against an in-memory fake of Compute Engine and GCS: standard and data
happy paths, every preflight refusal, drift during data migration, prod approval enforcement and self-approval,
validation failure, interrupted cutover (VM left with no boot disk) recovered by rollback, rollback re-run after a
failure, and rollback after a successful migration. Also run [`actionlint`](https://github.com/rhysd/actionlint)
on the workflows in CI.

## Before production

- Pilot on low-risk non-prod VMs: standard, data and rollback paths, including a deliberately failed validation.
- Confirm on real VMs: boot-disk detach/attach on your VM shapes, CMEK on snapshots and disks, snapshot schedule
  re-attachment, OS detection (OS Config agent / serial output), ephemeral external IP behaviour.
- **Terraform**: the boot disk swap creates drift. Freeze applies for the VM during migration, then reconcile
  state/config (for example `terraform import`/`state mv` of the new disk, or `lifecycle.ignore_changes` on
  `boot_disk`) and review the plan so Terraform never recreates the VM or reverts the disk.
- Pin third-party actions to commit SHAs per your supply-chain policy.
- Agree the retention period and the separate manual cleanup process (Debian disk, snapshots, RHEL disk after a
  rollback). Resources are labelled `rhel-migration-id`, `rhel-migration-vm`, `rhel-migration-role` to find them.
- Out of scope / refused by preflight: managed instance groups (migrate the template), VMs with local SSDs,
  boot disks that cannot be proven Debian 10.
